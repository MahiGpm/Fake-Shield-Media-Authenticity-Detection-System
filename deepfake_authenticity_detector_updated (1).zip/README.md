# VeriFace AI: Deepfake Media Authenticity Detection System

[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-19+-61DAFB.svg)](https://react.dev/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-EE4C2C.svg)](https://pytorch.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-v4-38B2AC.svg)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-Apache%202.0-green.svg)](LICENSE)

A production-grade, full-stack digital forensics and deepfake verification system developed as a **Final Year Engineering Capstone Project**. Built with a **Python FastAPI** backend powered by a real pretrained **Vision Transformer (ViT-Base)** classifier, and a high-performance **React + Vite + Tailwind CSS** cyber-forensics dashboard.

---

## 🌟 Key Features

1. **Pretrained Vision Transformer (ViT) Inference**:
   - Executes real deepfake classification via the fine-tuned `dima806/deepfake_vs_real_image_detection` Vision Transformer.
   - Outputs discrete predicted class (`REAL` or `FAKE`), confidence percentage, latency in milliseconds, and hardware dispatch info.
   - **Zero fake/random mock scores**: Real model inference is executed on every uploaded image.

2. **Forensic Multi-Level Validation**:
   - Drag-and-drop file ingestion supporting **JPG, JPEG, PNG, WEBP** (up to 15 MB).
   - Magic bytes header integrity checks preventing file spoofing attacks.
   - Error Level Analysis (ELA) compression discrepancy scoring.

3. **Persistent SQLite Audit History**:
   - Automatically records every analysis into a local SQLite database (`deepfake_history.db`).
   - Tracks IDs, filenames, resolutions, verdicts, confidence scores, latencies, and timestamps.
   - Filterable by status (`ALL`, `REAL`, `FAKE`) and searchable by filename.

4. **Transparent Limitation Reporting & Labeled Fallback**:
   - Calls out model boundaries (blur sensitivity, compression artifacts, facial optimization).
   - If offline or model loading fails, clearly identifies the issue and runs an explicitly labeled **DEMO MODE** without claiming fake predictions are real.

---

## 🏗️ Architecture & Tech Stack

```mermaid
flowchart LR
    A["Client Browser\n(React 19 + Tailwind v4)"] -->|POST /api/analyze| B["FastAPI Backend\n(Port 8000)"]
    B --> C["Validation Layer\n(Pillow & Magic Bytes)"]
    C --> D["Inference Service\n(PyTorch ViT-Base)"]
    C --> E["Forensic ELA\n(OpenCV & NumPy)"]
    D --> F["SQLite DB\n(deepfake_history.db)"]
    E --> F
    F -->|JSON Response| A
```

- **Frontend**: React 19, Vite 8, Tailwind CSS v4, Lucide React icons.
- **Backend**: FastAPI, Uvicorn, Pydantic, Python-Multipart.
- **Machine Learning**: PyTorch, Hugging Face Transformers, Torchvision.
- **Computer Vision**: OpenCV, Pillow, NumPy.
- **Database**: SQLite3 (embedded, zero configuration required).
- **Test Suite**: Pytest, HTTPX TestClient.

---

## 🚀 Quick Start Guide

### Prerequisites
- **Python 3.10+** (Python 3.11 tested)
- **Node.js 18+** & **npm**

---

### Step 1: Install Backend Dependencies

Open your terminal, navigate to the `backend` folder:
```bash
cd backend
pip install -r requirements.txt
```

---

### Step 2: Run Automated Backend Tests

Verify that all unit tests pass (model loading, validation, inference, and database persistence):
```bash
pytest -v
```
**Expected Output:**
```text
test_backend.py::test_health_endpoint PASSED                             [ 14%]
test_backend.py::test_reject_unsupported_file_extension PASSED           [ 28%]
test_backend.py::test_reject_corrupted_file_with_valid_extension PASSED  [ 42%]
test_backend.py::test_reject_empty_file PASSED                           [ 57%]
test_backend.py::test_analyze_valid_jpeg_real_ai_inference PASSED        [ 71%]
test_backend.py::test_analyze_valid_png PASSED                           [ 85%]
test_backend.py::test_sqlite_history_persistence PASSED                  [100%]

======================== 7 passed in ~9.5s ========================
```

---

### Step 3: Launch the FastAPI Backend Server

```bash
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```
**Expected Output:**
```text
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Loading pretrained model: dima806/deepfake_vs_real_image_detection
INFO:     Pretrained ViT model loaded and warmed up successfully.
INFO:     FastAPI Deepfake Detection Service initialized.
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
```

The interactive Swagger documentation is available at: **http://127.0.0.1:8000/docs**

---

### Step 4: Launch the React + Vite Frontend

In a **new terminal window**, navigate to the `frontend` folder:
```bash
cd frontend
npm install
npm run dev
```

**Expected Output:**
```text
  VITE v8.3.5  ready in 240 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

Open your browser to: **http://localhost:5173**

---

## 📡 REST API Specification

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Returns AI model readiness, device, and service status. |
| `POST` | `/api/analyze` | Accepts multipart image `file`, performs ViT inference. |
| `POST` | `/api/analyze/video` | Uniformly samples up to 64 video frames and runs the image detector per frame. Supports MP4, MOV, AVI, MKV, WEBM (100 MB max). |
| `GET` | `/api/history` | Fetches historical verification records from SQLite. |
| `GET` | `/api/history/{id}` | Fetches detailed audit log for a single analysis. |
| `DELETE` | `/api/history` | Clears all historical records from SQLite database. |

---

## 🧠 Pretrained Model Specifications

| Parameter | Specification |
|---|---|
| **Model Repository** | `dima806/deepfake_vs_real_image_detection` (Hugging Face) |
| **Base Architecture** | `google/vit-base-patch16-224-in21k` |
| **Parameters** | 86 Million |
| **Training Dataset** | 140,000+ Real & Deepfake Faces (FaceForensics++, Celeb-DF, StyleGAN) |
| **Input Resolution** | 224 x 224 x 3 (RGB) |
| **Output Classes** | `Real` (Index 0), `Fake` (Index 1) |
| **Open Source License** | Apache 2.0 (Permissive Academic & Commercial) |

---

## Video analysis note

The video endpoint reuses the image classifier on sampled frames and combines frame scores with a heuristic. It is not a dedicated temporal deepfake model, does not analyze audio, and can miss manipulations in unsampled frames. Check the model labels and validate performance on held-out labeled real/fake media before making claims about accuracy.

## 🔬 System Limitations

1. **Facial Domain**: The model is fine-tuned primarily on human faces; performance on non-facial landscape or abstract images is not guaranteed.
2. **Heavy Compression**: Multiple rounds of lossy JPEG re-compression (e.g. messaging apps) can degrade high-frequency synthetic artifacts.
3. **Emerging Generative Models**: New diffusion architectures (Flux, Midjourney v6) may exhibit different pixel residual distributions than classic GAN training sets.
4. **Legal Scope**: AI classification scores provide probabilistic evidentiary indicators and should be corroborated by metadata and human forensic expertise.

---

## 👨‍💻 Project Directory Structure

```
deepfake_authenticity_detector/
├── README.md                   # Complete documentation and launch manual
├── backend/
│   ├── main.py                 # FastAPI endpoints & CORS configuration
│   ├── model_service.py        # Pretrained Vision Transformer inference service
│   ├── image_utils.py          # Validation, magic bytes, ELA, temp file cleanup
│   ├── database.py             # SQLite database layer & schema
│   ├── test_backend.py         # Automated pytest test suite (7 tests)
│   ├── requirements.txt        # Backend dependencies
│   └── deepfake_history.db     # SQLite database file (created at runtime)
└── frontend/
    ├── package.json            # React 19 dependencies & scripts
    ├── vite.config.js          # Vite config with API reverse proxy
    ├── src/
    │   ├── App.jsx             # Main dashboard container
    │   ├── index.css           # Tailwind CSS imports
    │   ├── main.jsx            # React root mount
    │   └── components/
    │       ├── Navbar.jsx          # Header with live AI health indicator
    │       ├── Dropzone.jsx        # Drag-and-drop file uploader & demo buttons
    │       ├── AnalysisResult.jsx  # Detailed forensic verdict, score, limitations
    │       ├── HistoryTable.jsx    # SQLite audit history data table
    │       └── ModelInfoModal.jsx  # ViT technical specs & licensing modal
```
