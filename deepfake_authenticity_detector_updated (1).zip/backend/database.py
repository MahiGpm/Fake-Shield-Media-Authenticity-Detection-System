"""
SQLite Database Layer for Deepfake Media Authenticity Detection History
"""

import sqlite3
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

DB_PATH = Path(__file__).resolve().parent / "deepfake_history.db"

def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    """Initializes the SQLite database with the analyses table schema."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filesize_kb REAL NOT NULL,
            image_width INTEGER NOT NULL,
            image_height INTEGER NOT NULL,
            predicted_class TEXT NOT NULL,
            confidence_score REAL NOT NULL,
            model_name TEXT NOT NULL,
            is_demo_mode INTEGER NOT NULL DEFAULT 0,
            processing_time_ms REAL NOT NULL,
            limitations TEXT NOT NULL,
            ela_score REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def save_analysis(record: Dict[str, Any]) -> int:
    """Saves a new analysis result and returns the created ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO analyses (
            filename, filesize_kb, image_width, image_height,
            predicted_class, confidence_score, model_name,
            is_demo_mode, processing_time_ms, limitations, ela_score
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        record.get("filename", "unknown"),
        record.get("filesize_kb", 0.0),
        record.get("image_width", 0),
        record.get("image_height", 0),
        record.get("predicted_class", "UNKNOWN"),
        record.get("confidence_score", 0.0),
        record.get("model_name", "Unknown Model"),
        1 if record.get("is_demo_mode", False) else 0,
        record.get("processing_time_ms", 0.0),
        record.get("limitations", ""),
        record.get("ela_score", 0.0)
    ))
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return new_id

def get_all_analyses(limit: int = 50) -> List[Dict[str, Any]]:
    """Retrieves recent analyses ordered by timestamp descending."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, filename, filesize_kb, image_width, image_height,
               predicted_class, confidence_score, model_name,
               is_demo_mode, processing_time_ms, limitations, ela_score, created_at
        FROM analyses
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_analysis_by_id(analysis_id: int) -> Optional[Dict[str, Any]]:
    """Retrieves a single analysis by its ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, filename, filesize_kb, image_width, image_height,
               predicted_class, confidence_score, model_name,
               is_demo_mode, processing_time_ms, limitations, ela_score, created_at
        FROM analyses
        WHERE id = ?
    """, (analysis_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def clear_all_analyses() -> bool:
    """Clears all history records."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM analyses")
    conn.commit()
    conn.close()
    return True

# Initialize database schema on module load
init_db()
