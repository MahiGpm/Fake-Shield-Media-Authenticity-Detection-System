"""
Image validation, processing, and temporary file lifecycle utilities.
"""

import io
import os
import uuid
import tempfile
from pathlib import Path
from typing import Tuple, Dict, Any, Generator
from contextlib import contextmanager
from PIL import Image, ImageChops, ImageEnhance
import cv2
import numpy as np

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
ALLOWED_MIME_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024  # 15 MB
MIN_DIMENSION = 32
MAX_DIMENSION = 8192

TEMP_DIR = Path(__file__).resolve().parent / "temp_uploads"
TEMP_DIR.mkdir(parents=True, exist_ok=True)

class ImageValidationError(Exception):
    """Custom exception raised when an image fails forensic validation."""
    pass

def validate_image_file(filename: str, file_bytes: bytes, content_type: str = "") -> Tuple[Image.Image, Dict[str, Any]]:
    """
    Validates uploaded file extension, size, magic bytes, and readable PIL image dimensions.
    Raises ImageValidationError if invalid.
    """
    # 1. Extension check
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ImageValidationError(
            f"Unsupported file format '{ext}'. Allowed formats: JPG, JPEG, PNG, WEBP."
        )

    # 2. File size check
    filesize = len(file_bytes)
    if filesize == 0:
        raise ImageValidationError("Uploaded file is empty (0 bytes).")
    if filesize > MAX_FILE_SIZE_BYTES:
        raise ImageValidationError(
            f"File size exceeds 15 MB limit ({filesize / (1024*1024):.2f} MB)."
        )

    # 3. Pillow Image verification (Magic Bytes check)
    try:
        pil_image = Image.open(io.BytesIO(file_bytes))
        pil_image.verify()  # Verifies header integrity
        # Re-open after verify() since verify() destroys file pointer
        pil_image = Image.open(io.BytesIO(file_bytes))
        pil_image.load()    # Ensures pixel data is decodable
    except Exception as e:
        raise ImageValidationError(f"Corrupted or invalid image data: {str(e)}")

    # 4. Dimension check
    width, height = pil_image.size
    if width < MIN_DIMENSION or height < MIN_DIMENSION:
        raise ImageValidationError(
            f"Image resolution too low ({width}x{height}px). Minimum is {MIN_DIMENSION}x{MIN_DIMENSION}px."
        )
    if width > MAX_DIMENSION or height > MAX_DIMENSION:
        raise ImageValidationError(
            f"Image resolution too high ({width}x{height}px). Maximum is {MAX_DIMENSION}x{MAX_DIMENSION}px."
        )

    # Convert to RGB if needed (handles RGBA, Palette, Grayscale)
    if pil_image.mode != "RGB":
        pil_image = pil_image.convert("RGB")

    metadata = {
        "filename": filename,
        "extension": ext,
        "filesize_bytes": filesize,
        "filesize_kb": round(filesize / 1024.0, 2),
        "width": width,
        "height": height,
        "format": pil_image.format or ext.replace(".", "").upper()
    }

    return pil_image, metadata

@contextmanager
def temporary_image_file(file_bytes: bytes, suffix: str = ".jpg") -> Generator[str, None, None]:
    """
    Context manager that saves uploaded bytes to a temporary file
    and guarantees immediate cleanup upon exit.
    """
    temp_filename = f"upload_{uuid.uuid4().hex[:12]}{suffix}"
    temp_path = TEMP_DIR / temp_filename
    try:
        with open(temp_path, "wb") as f:
            f.write(file_bytes)
        yield str(temp_path)
    finally:
        if temp_path.exists():
            try:
                os.remove(temp_path)
            except OSError:
                pass

def compute_ela_score(pil_img: Image.Image, quality: int = 90) -> float:
    """
    Computes standard Error Level Analysis (ELA) anomaly score.
    Returns value between 0.0 (natural) and 1.0 (anomalous).
    """
    try:
        buffer = io.BytesIO()
        pil_img.save(buffer, format='JPEG', quality=quality)
        buffer.seek(0)
        recompressed = Image.open(buffer)
        diff = ImageChops.difference(pil_img, recompressed)
        diff_arr = np.array(diff, dtype=np.float32)
        std_err = float(np.std(diff_arr))
        # Normalized anomaly estimate
        return round(float(np.clip(std_err / 20.0, 0.05, 0.95)), 4)
    except Exception:
        return 0.15
