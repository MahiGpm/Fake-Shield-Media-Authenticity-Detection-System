"""
FastAPI Backend Application for Deepfake Media Authenticity Detection System
Provides REST endpoints for real-time AI inference, digital forensics, and SQLite audit history.
"""

import io
import os
import time
import base64
import logging
import tempfile
from pathlib import Path
from contextlib import asynccontextmanager
from typing import Dict, Any, List
from fastapi import FastAPI, File, UploadFile, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from PIL import Image
import cv2

from database import init_db, save_analysis, get_all_analyses, get_analysis_by_id, clear_all_analyses
from image_utils import validate_image_file, compute_ela_score, ImageValidationError, temporary_image_file
from model_service import model_service, MODEL_DISPLAY_NAME

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("DeepfakeAPI")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event handler verifying database schema on startup."""
    init_db()
    logger.info("FastAPI Deepfake Detection Service initialized.")
    yield

app = FastAPI(
    title="Deepfake Media Authenticity Detection API",
    description="Production-grade digital forensics and deepfake verification backend powered by PyTorch and Vision Transformers.",
    version="1.0.0",
    lifespan=lifespan
)

@app.get("/api/health")
def health_check() -> Dict[str, Any]:
    """Health check endpoint exposing system status, AI model readiness, and hardware acceleration."""
    return {
        "status": "online",
        "model_ready": model_service.is_ready,
        "model_name": MODEL_DISPLAY_NAME,
        "is_demo_mode": model_service.is_demo_mode,
        "load_error": model_service.load_error,
        "video_endpoint": "/api/analyze/video",
        "device": str(model_service.device),
        "database": "sqlite_connected"
    }

@app.post("/api/analyze")
async def analyze_image(file: UploadFile = File(...)) -> Dict[str, Any]:
    """
    Main forensic inference endpoint.
    1. Validates uploaded file (magic bytes, size, dimensions, format).
    2. Runs pretrained Vision Transformer deepfake inference.
    3. Computes supplementary Error Level Analysis (ELA) compression metric.
    4. Records the forensic audit trail in SQLite.
    5. Returns comprehensive forensic verdict and metadata.
    """
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No filename provided in upload payload."
        )

    # Read binary stream
    try:
        file_bytes = await file.read()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to read upload stream: {str(e)}"
        )

    # 1. Validation & Preprocessing
    try:
        pil_image, meta = validate_image_file(file.filename, file_bytes, file.content_type or "")
    except ImageValidationError as ve:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(ve)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Image decoding failure: {str(e)}"
        )

    # 2. Real AI Inference using Pretrained Model
    prediction = model_service.predict(pil_image)

    # 3. Supplementary Forensic: Error Level Analysis
    ela_score = compute_ela_score(pil_image)

    # 4. Generate thumbnail preview (base64) for instant frontend UI feedback
    thumb_buf = io.BytesIO()
    thumb = pil_image.copy()
    thumb.thumbnail((320, 320))
    thumb.save(thumb_buf, format="JPEG", quality=80)
    thumb_b64 = f"data:image/jpeg;base64,{base64.b64encode(thumb_buf.getvalue()).decode('utf-8')}"

    # 5. Persist to SQLite
    record_to_save = {
        "filename": meta["filename"],
        "filesize_kb": meta["filesize_kb"],
        "image_width": meta["width"],
        "image_height": meta["height"],
        "predicted_class": prediction["predicted_class"],
        "confidence_score": prediction["confidence_score"],
        "model_name": prediction["model_name"],
        "is_demo_mode": prediction["is_demo_mode"],
        "processing_time_ms": prediction["processing_time_ms"],
        "limitations": prediction["limitations"],
        "ela_score": ela_score
    }
    created_id = save_analysis(record_to_save)

    # Assemble comprehensive response payload
    return {
        "id": created_id,
        "filename": meta["filename"],
        "filesize_kb": meta["filesize_kb"],
        "image_width": meta["width"],
        "image_height": meta["height"],
        "image_format": meta["format"],
        "predicted_class": prediction["predicted_class"],
        "confidence_score": prediction["confidence_score"],
        "confidence_percentage": round(prediction["confidence_score"] * 100.0, 1),
        "real_probability": prediction.get("real_probability", 0.0),
        "fake_probability": prediction.get("fake_probability", 0.0),
        "model_name": prediction["model_name"],
        "architecture": prediction.get("architecture", "Vision Transformer"),
        "is_demo_mode": prediction["is_demo_mode"],
        "processing_time_ms": prediction["processing_time_ms"],
        "limitations": prediction["limitations"],
        "ela_score": ela_score,
        "device_used": prediction.get("device_used", "CPU"),
        "preview_base64": thumb_b64
    }


VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}
MAX_VIDEO_BYTES = 100 * 1024 * 1024
MAX_VIDEO_FRAMES = 64
VIDEO_LIMITATIONS = (
    "Frame-based screening only. Unsampled frames or brief manipulations may be missed; "
    "frame probabilities are not calibrated forensic certainty. This endpoint does not "
    "perform audio deepfake detection or full spatiotemporal neural modeling."
)


def _analyze_video_path(video_path: str, filename: str, filesize_bytes: int) -> Dict[str, Any]:
    """Uniformly sample a video and classify frames using the configured image detector."""
    if not model_service.is_ready or model_service.model is None:
        raise RuntimeError(
            "The trained image detector is not ready. Check /api/health and model download/configuration."
        )

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError("Could not decode the uploaded video. Try a supported MP4/H.264 file.")

    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    if total_frames < 1:
        cap.release()
        raise ValueError("Video contains no readable frames or has invalid metadata.")

    # Uniform sampling includes the start and end. Short clips use every frame.
    indices = list(dict.fromkeys(
        int(x) for x in __import__("numpy").linspace(
            0, total_frames - 1, min(total_frames, MAX_VIDEO_FRAMES), dtype=int
        )
    ))
    frame_results = []
    preview_b64 = None
    started = time.perf_counter()
    try:
        for index in indices:
            cap.set(cv2.CAP_PROP_POS_FRAMES, index)
            ok, frame = cap.read()
            if not ok:
                continue
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = Image.fromarray(rgb)
            pred = model_service.predict(image)
            if pred.get("is_demo_mode") or pred.get("predicted_class") not in {"REAL", "FAKE"}:
                raise RuntimeError("Model returned a demo/error result; video classification stopped.")
            fake_prob = float(pred["fake_probability"])
            frame_results.append({
                "frame_index": index,
                "timestamp_sec": round(index / fps, 3) if fps > 0 else None,
                "predicted_class": pred["predicted_class"],
                "fake_probability": round(fake_prob, 4),
                "real_probability": round(float(pred["real_probability"]), 4),
            })
            if preview_b64 is None:
                thumb = image.copy()
                thumb.thumbnail((320, 320))
                buf = io.BytesIO()
                thumb.save(buf, format="JPEG", quality=80)
                preview_b64 = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
    finally:
        cap.release()

    if not frame_results:
        raise ValueError("No frames could be decoded from this video.")

    import numpy as np
    scores = np.asarray([r["fake_probability"] for r in frame_results], dtype=float)
    mean_fake = float(np.mean(scores))
    p90_fake = float(np.percentile(scores, 90))
    peak_fake = float(np.max(scores))
    # Explicitly a heuristic aggregation, not a calibrated probability.
    overall_fake = float(np.clip(0.7 * mean_fake + 0.3 * p90_fake, 0.0, 1.0))
    threshold = float(os.getenv("FAKE_THRESHOLD", "0.5"))
    verdict = "FAKE" if overall_fake >= threshold else "REAL"
    confidence = max(overall_fake, 1.0 - overall_fake)
    peak = max(frame_results, key=lambda r: r["fake_probability"])
    return {
        "id": None,
        "filename": Path(filename).name,
        "filesize_kb": round(filesize_bytes / 1024.0, 2),
        "media_type": "video",
        "image_width": width,
        "image_height": height,
        "fps": round(fps, 3) if fps > 0 else None,
        "total_frames": total_frames,
        "duration_sec": round(total_frames / fps, 3) if fps > 0 else None,
        "frames_analyzed": len(frame_results),
        "predicted_class": verdict,
        "confidence_score": round(confidence, 4),
        "confidence_percentage": round(confidence * 100.0, 2),
        "real_probability": round(1.0 - overall_fake, 4),
        "fake_probability": round(overall_fake, 4),
        "overall_fake_probability": round(overall_fake, 4),
        "mean_fake_probability": round(mean_fake, 4),
        "p90_fake_probability": round(p90_fake, 4),
        "peak_fake_probability": round(peak_fake, 4),
        "manipulated_frames_count": sum(r["fake_probability"] >= threshold for r in frame_results),
        "peak_timestamp_sec": peak["timestamp_sec"],
        "frame_results": frame_results,
        "model_name": MODEL_DISPLAY_NAME + " (uniformly sampled video frames)",
        "architecture": "Per-frame ViT classification with heuristic aggregation",
        "is_demo_mode": False,
        "processing_time_ms": round((time.perf_counter() - started) * 1000.0, 2),
        "limitations": VIDEO_LIMITATIONS,
        "device_used": str(model_service.device).upper(),
        "preview_base64": preview_b64,
    }


@app.post("/api/analyze/video")
async def analyze_video(file: UploadFile = File(...)) -> Dict[str, Any]:
    """Analyze uniformly sampled frames from a video using the configured image model."""
    filename = file.filename or ""
    suffix = Path(filename).suffix.lower()
    if suffix not in VIDEO_EXTENSIONS:
        await file.close()
        raise HTTPException(status_code=422, detail="Unsupported video format. Use MP4, MOV, AVI, MKV, or WEBM.")

    temp_path = None
    size = 0
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            temp_path = tmp.name
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_VIDEO_BYTES:
                    raise HTTPException(status_code=413, detail="Video exceeds the 100 MB upload limit.")
                tmp.write(chunk)
        if size == 0:
            raise HTTPException(status_code=422, detail="Uploaded video is empty.")
        # OpenCV and PyTorch inference are blocking; execute off the async event loop.
        import asyncio
        import functools
        return await asyncio.get_running_loop().run_in_executor(
            None, functools.partial(_analyze_video_path, temp_path, filename, size)
        )
    except HTTPException:
        raise
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Video analysis failed")
        raise HTTPException(status_code=500, detail=f"Video analysis failed: {exc}") from exc
    finally:
        await file.close()
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                logger.warning("Could not remove temporary video: %s", temp_path)


@app.get("/api/history")
def get_history(limit: int = 50) -> List[Dict[str, Any]]:
    """Retrieves chronological analysis history from SQLite database."""
    try:
        return get_all_analyses(limit=limit)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database retrieval error: {str(e)}"
        )

@app.get("/api/history/{analysis_id}")
def get_history_detail(analysis_id: int) -> Dict[str, Any]:
    """Retrieves a single historical record by ID."""
    record = get_analysis_by_id(analysis_id)
    if not record:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Analysis record with ID {analysis_id} not found."
        )
    return record

@app.delete("/api/history")
def clear_history() -> Dict[str, str]:
    """Clears all audit logs from SQLite database."""
    try:
        clear_all_analyses()
        return {"status": "success", "message": "Analysis history cleared successfully."}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to clear history: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
