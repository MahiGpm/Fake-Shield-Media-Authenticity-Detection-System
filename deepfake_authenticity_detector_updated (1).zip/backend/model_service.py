"""
Model Service: Pretrained Vision Transformer (ViT) Deepfake Detector
Loads and executes inference using the pretrained 'dima806/deepfake_vs_real_image_detection' model.
Handles warm-up, GPU/CPU dispatch, inference timing, and clear limitation reporting.
"""

import time
import logging
import os
from typing import Dict, Any, Tuple
from PIL import Image
import torch

logger = logging.getLogger(__name__)

# Primary pretrained model from Hugging Face
MODEL_ID = "dima806/deepfake_vs_real_image_detection"
MODEL_DISPLAY_NAME = "Vision Transformer (ViT-Base) Deepfake Detector"
MODEL_ARCHITECTURE = "ViT-Base / Patch16 (Fine-tuned on 140k+ Real & Deepfake Faces)"

MODEL_LIMITATIONS = (
    "1. Optimized primarily for human facial regions; performance on landscapes or abstract art may vary. "
    "2. Heavy compression, low-resolution (<128px), or extreme motion blur can reduce detection accuracy. "
    "3. Emerging generative diffusion models (Flux, Midjourney v6) may exhibit subtle novel artifacts not present in classic GAN training sets. "
    "4. Forensic results should be treated as evidentiary probability indicators rather than absolute legal proof."
)

class DeepfakeModelService:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.processor = None
        self.model = None
        self.is_ready = False
        self.load_error = None
        self.is_demo_mode = False
        self._load_model()

    def _load_model(self):
        """Loads the pretrained Hugging Face ViT model into memory."""
        try:
            logger.info(f"Loading pretrained model: {MODEL_ID} on device: {self.device}")
            from transformers import AutoImageProcessor, AutoModelForImageClassification
            self.processor = AutoImageProcessor.from_pretrained(MODEL_ID)
            self.model = AutoModelForImageClassification.from_pretrained(MODEL_ID)
            self.model.to(self.device)
            self.model.eval()

            # Warm-up pass
            dummy_img = Image.new("RGB", (224, 224), color=(128, 128, 128))
            inputs = self.processor(images=dummy_img, return_tensors="pt").to(self.device)
            with torch.no_grad():
                _ = self.model(**inputs)

            self.is_ready = True
            self.is_demo_mode = False
            logger.info("Pretrained ViT model loaded and warmed up successfully.")
        except Exception as e:
            self.is_ready = False
            self.load_error = str(e)
            self.is_demo_mode = True
            logger.error(f"Failed to load pretrained model '{MODEL_ID}': {e}. System running in LABELED DEMO FALLBACK MODE.")

    def predict(self, pil_image: Image.Image) -> Dict[str, Any]:
        """
        Runs inference on a PIL Image.
        Returns:
            Dict containing:
                predicted_class: 'REAL' or 'FAKE'
                confidence_score: float (0.0 to 1.0)
                real_probability: float (0.0 to 1.0)
                fake_probability: float (0.0 to 1.0)
                model_name: str
                is_demo_mode: bool
                processing_time_ms: float
                limitations: str
                device_used: str
        """
        start_time = time.perf_counter()

        if not self.is_ready or self.model is None or self.processor is None:
            # Explicit labeled fallback mode if model failed to load
            elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)
            return {
                "predicted_class": "INCONCLUSIVE (DEMO MODE)",
                "confidence_score": 0.50,
                "real_probability": 0.50,
                "fake_probability": 0.50,
                "model_name": f"{MODEL_DISPLAY_NAME} [OFFLINE DEMO FALLBACK]",
                "is_demo_mode": True,
                "processing_time_ms": elapsed_ms,
                "limitations": f"DEMO MODE ACTIVE: Pretrained model could not be loaded ({self.load_error}). This is a mock response, NOT a real prediction. {MODEL_LIMITATIONS}",
                "device_used": "N/A"
            }

        try:
            # Ensure 3-channel RGB
            if pil_image.mode != "RGB":
                pil_image = pil_image.convert("RGB")

            # Preprocess image for ViT (resize, normalize)
            inputs = self.processor(images=pil_image, return_tensors="pt").to(self.device)

            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probabilities = torch.softmax(logits, dim=1).squeeze().cpu().numpy()

            # Resolve class mapping from the checkpoint labels; never assume order.
            labels = {
                int(index): str(label).strip().lower()
                for index, label in self.model.config.id2label.items()
            }
            real_override = os.getenv("REAL_LABEL_INDEX")
            fake_override = os.getenv("FAKE_LABEL_INDEX")
            real_ids = [
                i for i, label in labels.items()
                if any(word in label for word in ("real", "authentic", "genuine"))
            ]
            fake_ids = [
                i for i, label in labels.items()
                if any(word in label for word in ("fake", "deepfake", "manipulated"))
            ]
            real_id = int(real_override) if real_override is not None else (real_ids[0] if len(real_ids) == 1 else None)
            fake_id = int(fake_override) if fake_override is not None else (fake_ids[0] if len(fake_ids) == 1 else None)
            if real_id is None or fake_id is None or real_id == fake_id:
                raise RuntimeError(
                    f"Cannot determine real/fake mapping from model labels {labels}. "
                    "Verify the model card and set REAL_LABEL_INDEX and FAKE_LABEL_INDEX if needed."
                )
            if real_id >= len(probabilities) or fake_id >= len(probabilities):
                raise RuntimeError(f"Configured class index is outside model outputs: {labels}")
            real_prob = float(probabilities[real_id])
            fake_prob = float(probabilities[fake_id])

            # Determine dominant prediction
            if fake_prob >= 0.50:
                predicted_class = "FAKE"
                confidence_score = fake_prob
            else:
                predicted_class = "REAL"
                confidence_score = real_prob

            elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)

            return {
                "predicted_class": predicted_class,
                "confidence_score": round(confidence_score, 4),
                "real_probability": round(real_prob, 4),
                "fake_probability": round(fake_prob, 4),
                "model_name": MODEL_DISPLAY_NAME,
                "architecture": MODEL_ARCHITECTURE,
                "is_demo_mode": False,
                "processing_time_ms": elapsed_ms,
                "limitations": MODEL_LIMITATIONS,
                "device_used": str(self.device).upper()
            }

        except Exception as e:
            elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)
            logger.error(f"Inference runtime error: {e}")
            return {
                "predicted_class": "ERROR",
                "confidence_score": 0.0,
                "real_probability": 0.0,
                "fake_probability": 0.0,
                "model_name": MODEL_DISPLAY_NAME,
                "is_demo_mode": True,
                "processing_time_ms": elapsed_ms,
                "limitations": f"Inference execution failed: {str(e)}",
                "device_used": str(self.device).upper()
            }

# Singleton instance for FastAPI application lifecycle
model_service = DeepfakeModelService()
