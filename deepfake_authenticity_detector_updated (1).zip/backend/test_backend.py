"""
Automated Backend Test Suite
Tests FastAPI health, validation rules, AI inference, and SQLite persistence.
"""

import io
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from main import app
from database import clear_all_analyses

client = TestClient(app)

def create_test_image(format="JPEG", size=(256, 256), color=(200, 100, 100)) -> bytes:
    """Helper creating memory buffer of valid test image."""
    buf = io.BytesIO()
    img = Image.new("RGB", size, color=color)
    img.save(buf, format=format)
    return buf.getvalue()

def setup_function():
    """Clear database before each test run."""
    clear_all_analyses()

def test_health_endpoint():
    """Verify health endpoint reports online status and model readiness."""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "online"
    assert "model_name" in data
    assert "device" in data
    assert data["database"] == "sqlite_connected"

def test_reject_unsupported_file_extension():
    """Verify that unsupported extensions (.txt) are rejected with 422."""
    files = {"file": ("document.txt", b"Hello world text file", "text/plain")}
    response = client.post("/api/analyze", files=files)
    assert response.status_code == 422
    assert "Unsupported file format" in response.json()["detail"]

def test_reject_corrupted_file_with_valid_extension():
    """Verify that a corrupted payload with .jpg extension fails magic byte validation."""
    files = {"file": ("fake_image.jpg", b"This is not a real JPEG image header", "image/jpeg")}
    response = client.post("/api/analyze", files=files)
    assert response.status_code in [400, 422]
    assert "Corrupted or invalid image" in response.json()["detail"]

def test_reject_empty_file():
    """Verify that a 0-byte file upload is rejected."""
    files = {"file": ("empty.png", b"", "image/png")}
    response = client.post("/api/analyze", files=files)
    assert response.status_code == 422
    assert "empty" in response.json()["detail"].lower()

def test_analyze_valid_jpeg_real_ai_inference():
    """
    Test real AI inference on a valid JPEG image.
    Verifies:
      - Predicted class is REAL or FAKE
      - Confidence score is a float in [0.0, 1.0]
      - Model name is populated
      - Processing time is reported (> 0 ms)
      - Limitations are clearly stated
      - is_demo_mode is False (real AI model is active)
    """
    img_bytes = create_test_image(format="JPEG", size=(224, 224), color=(140, 150, 160))
    files = {"file": ("portrait_test.jpg", img_bytes, "image/jpeg")}
    response = client.post("/api/analyze", files=files)
    assert response.status_code == 200
    data = response.json()

    assert data["predicted_class"] in ["REAL", "FAKE"]
    assert 0.0 <= data["confidence_score"] <= 1.0
    assert 0.0 <= data["real_probability"] <= 1.0
    assert 0.0 <= data["fake_probability"] <= 1.0
    assert data["processing_time_ms"] > 0
    assert len(data["model_name"]) > 0
    assert len(data["limitations"]) > 0
    assert data["is_demo_mode"] is False
    assert "preview_base64" in data
    assert data["image_width"] == 224
    assert data["image_height"] == 224

def test_analyze_valid_png():
    """Verify PNG format support."""
    img_bytes = create_test_image(format="PNG", size=(128, 128), color=(90, 120, 180))
    files = {"file": ("avatar.png", img_bytes, "image/png")}
    response = client.post("/api/analyze", files=files)
    assert response.status_code == 200
    data = response.json()
    assert data["image_format"] == "PNG"
    assert data["predicted_class"] in ["REAL", "FAKE"]

def test_sqlite_history_persistence():
    """Verify that analyzing an image records it into SQLite and can be retrieved."""
    # 1. Initially history is empty
    hist_resp = client.get("/api/history")
    assert hist_resp.status_code == 200
    assert len(hist_resp.json()) == 0

    # 2. Analyze an image
    img_bytes = create_test_image(format="JPEG", size=(200, 200))
    client.post("/api/analyze", files={"file": ("history_test.jpg", img_bytes, "image/jpeg")})

    # 3. Retrieve history and verify record
    hist_resp2 = client.get("/api/history")
    assert hist_resp2.status_code == 200
    history = hist_resp2.json()
    assert len(history) == 1
    record = history[0]
    assert record["filename"] == "history_test.jpg"
    assert record["predicted_class"] in ["REAL", "FAKE"]
    assert record["confidence_score"] >= 0.0

    # 4. Retrieve single record by ID
    single_resp = client.get(f"/api/history/{record['id']}")
    assert single_resp.status_code == 200
    assert single_resp.json()["filename"] == "history_test.jpg"

    # 5. Clear history
    del_resp = client.delete("/api/history")
    assert del_resp.status_code == 200
    hist_resp3 = client.get("/api/history")
    assert len(hist_resp3.json()) == 0
