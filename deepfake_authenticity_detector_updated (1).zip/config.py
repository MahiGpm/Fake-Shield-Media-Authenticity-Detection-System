"""
System Configuration & Global Parameters
Deepfake Media Authenticity Detection System
"""

import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"
WEIGHTS_DIR = MODELS_DIR / "weights"
FORENSICS_DIR = BASE_DIR / "forensics"
UTILS_DIR = BASE_DIR / "utils"
SAMPLES_DIR = BASE_DIR / "samples"
TEMP_DIR = BASE_DIR / "temp"

# Ensure runtime directories exist
TEMP_DIR.mkdir(parents=True, exist_ok=True)
WEIGHTS_DIR.mkdir(parents=True, exist_ok=True)

# Image & Video Processing Parameters
IMAGE_SIZE = (256, 256)
NORM_MEAN = [0.485, 0.456, 0.406]
NORM_STD = [0.229, 0.224, 0.225]

# Detection Thresholds
FAKE_THRESHOLD = 0.50
HIGH_CONFIDENCE_THRESHOLD = 0.75
SUSPICIOUS_THRESHOLD = 0.40

# Ensemble Weighting Scheme (Total = 1.0)
WEIGHT_SPATIAL_DL = 0.45      # MesoNet-4 / Spatial Deep Learning
WEIGHT_FREQUENCY_FFT = 0.20    # 2D FFT Spectral Distribution Forensics
WEIGHT_COMPRESSION_ELA = 0.20  # Error Level Analysis
WEIGHT_BOUNDARY_NOISE = 0.15   # Face boundary seam & noise variance

# Video Analysis Parameters
DEFAULT_VIDEO_SAMPLE_INTERVAL = 5  # Sample every Nth frame
MAX_FRAMES_ANALYZE = 90            # Maximum frames evaluated per video
TEMPORAL_FLICKER_THRESHOLD = 0.18  # Frame-to-frame score divergence threshold

# UI Customization
APP_TITLE = "VeriFace AI | Deepfake Forensic Authenticity Engine"
APP_SUBTITLE = "Multimodal Forensic Analysis & Explainable AI for Digital Media Verification"
VERSION = "2.4.0 (Enterprise Forensic Edition)"
