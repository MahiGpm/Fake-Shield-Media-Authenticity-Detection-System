"""
Error Level Analysis (ELA) Forensic Module
Detects JPEG compression rate inconsistencies indicative of image splicing and generative manipulation.
Computes localized compression disparity between central facial region and surrounding context.
"""

import io
import cv2
import numpy as np
from PIL import Image, ImageChops, ImageEnhance

class ELAnalyzer:
    def __init__(self, quality=90, scale_multiplier=15):
        self.quality = quality
        self.scale_multiplier = scale_multiplier

    def compute_ela(self, image_input):
        """
        Computes ELA on a PIL Image or numpy RGB image.
        Returns:
            dict containing ELA metrics, visualizations, and localized anomaly scores.
        """
        if isinstance(image_input, np.ndarray):
            orig_pil = Image.fromarray(image_input).convert('RGB')
        elif isinstance(image_input, Image.Image):
            orig_pil = image_input.convert('RGB')
        else:
            raise ValueError("Input must be a PIL Image or numpy array")

        # Step 1: Compress to memory buffer at specified quality
        buffer = io.BytesIO()
        orig_pil.save(buffer, format='JPEG', quality=self.quality)
        buffer.seek(0)
        recompressed_pil = Image.open(buffer)

        # Step 2: Compute absolute difference
        ela_diff = ImageChops.difference(orig_pil, recompressed_pil)

        # Step 3: Compute extrema and scaling factor
        extrema = ela_diff.getextrema()
        max_diff = max([ex[1] for ex in extrema]) if extrema else 1
        if max_diff == 0:
            max_diff = 1
        scale = 255.0 / max_diff

        # Scaled visualization
        ela_visual = ImageEnhance.Brightness(ela_diff).enhance(scale * (self.scale_multiplier / 10.0))

        # Convert to numpy array for numerical metrics
        diff_arr = np.array(ela_diff, dtype=np.float32)
        mean_err = float(np.mean(diff_arr))
        max_err = float(np.max(diff_arr))
        std_err = float(np.std(diff_arr))

        # Localized Discrepancy Analysis (Face Center vs Outer Margin)
        h, w = diff_arr.shape[:2]
        ch_s, ch_e = int(h * 0.25), int(h * 0.75)
        cw_s, cw_e = int(w * 0.25), int(w * 0.75)

        center_crop = diff_arr[ch_s:ch_e, cw_s:cw_e]
        center_mean = float(np.mean(center_crop))

        # Border region
        mask = np.ones((h, w), dtype=bool)
        mask[ch_s:ch_e, cw_s:cw_e] = False
        border_mean = float(np.mean(diff_arr[mask])) if np.any(mask) else center_mean

        # Discrepancy ratio: high when center was pasted or recompressed differently
        diff_spread = abs(center_mean - border_mean)
        base_denom = max(border_mean, 1.5)
        ratio_discrepancy = min(1.0, (diff_spread / base_denom) * 1.8)

        # ELA Anomaly Score
        # In natural unedited images, center and border have near-identical compression error.
        # In deepfakes/splices, error levels diverge significantly.
        anomaly_score = float(np.clip(
            0.65 * ratio_discrepancy + 0.35 * min(1.0, std_err / 22.0),
            0.05, 0.98
        ))

        # Generate false-color thermal heatmap
        gray_diff = cv2.cvtColor(np.array(ela_visual), cv2.COLOR_RGB2GRAY)
        heatmap_bgr = cv2.applyColorMap(gray_diff, cv2.COLORMAP_JET)

        return {
            'ela_image': ela_visual,
            'ela_heatmap': heatmap_bgr,
            'mean_error': round(mean_err, 3),
            'max_error': round(max_err, 3),
            'std_error': round(std_err, 3),
            'center_mean': round(center_mean, 3),
            'border_mean': round(border_mean, 3),
            'discrepancy_ratio': round(ratio_discrepancy, 4),
            'anomaly_score': round(anomaly_score, 4)
        }
