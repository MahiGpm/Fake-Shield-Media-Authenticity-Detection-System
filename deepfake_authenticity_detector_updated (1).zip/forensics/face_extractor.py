"""
Facial Landmark and Bounding Box Extraction Module
Resilient multi-tier face detection with Haar Cascade, contour analysis, and adaptive crop fallbacks.
"""

import cv2
import numpy as np
from PIL import Image

class FaceExtractor:
    def __init__(self, scale_factor=1.1, min_neighbors=5, min_size=(60, 60)):
        self.scale_factor = scale_factor
        self.min_neighbors = min_neighbors
        self.min_size = min_size
        self.face_cascade = None

        # Check for CascadeClassifier support
        if hasattr(cv2, 'CascadeClassifier') and hasattr(cv2, 'data') and hasattr(cv2.data, 'haarcascades'):
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            try:
                self.face_cascade = cv2.CascadeClassifier(cascade_path)
            except Exception:
                self.face_cascade = None

    def _fallback_contour_detect(self, bgr_img):
        """Skin color & contour based face localization when cascade is unavailable."""
        h, w = bgr_img.shape[:2]
        hsv = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2HSV)
        # Skin color range in HSV
        lower_skin = np.array([0, 30, 60], dtype=np.uint8)
        upper_skin = np.array([25, 200, 255], dtype=np.uint8)
        mask = cv2.inRange(hsv, lower_skin, upper_skin)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        boxes = []
        for c in contours:
            x, y, cw, ch = cv2.boundingRect(c)
            aspect = ch / float(cw) if cw > 0 else 0
            if cw > 50 and ch > 50 and 0.8 < aspect < 2.0:
                boxes.append((x, y, cw, ch))
        return boxes

    def detect_and_crop(self, image_input, pad_ratio=0.18):
        """
        Detects faces in an image (numpy array BGR/RGB, or PIL Image).
        Returns:
            list of dicts with detected/cropped faces and bounding box metadata.
        """
        if isinstance(image_input, Image.Image):
            rgb_img = np.array(image_input.convert('RGB'))
            bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
        elif isinstance(image_input, np.ndarray):
            if len(image_input.shape) == 2:
                bgr_img = cv2.cvtColor(image_input, cv2.COLOR_GRAY2BGR)
                rgb_img = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2RGB)
            elif image_input.shape[2] == 4:
                rgb_img = cv2.cvtColor(image_input, cv2.COLOR_RGBA2RGB)
                bgr_img = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR)
            else:
                bgr_img = image_input.copy()
                rgb_img = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2RGB)
        else:
            raise ValueError("Unsupported image input type")

        height, width = bgr_img.shape[:2]
        faces = []

        if self.face_cascade is not None and not self.face_cascade.empty():
            gray = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2GRAY)
            gray = cv2.equalizeHist(gray)
            detected = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=self.scale_factor,
                minNeighbors=self.min_neighbors,
                minSize=self.min_size
            )
            if len(detected) > 0:
                faces = list(detected)

        if len(faces) == 0:
            contour_faces = self._fallback_contour_detect(bgr_img)
            if contour_faces:
                faces = contour_faces

        results = []
        if len(faces) == 0:
            # Center region fallback
            cw, ch = int(width * 0.75), int(height * 0.75)
            cx, cy = (width - cw) // 2, (height - ch) // 2
            crop_bgr = bgr_img[cy:cy+ch, cx:cx+cw]
            crop_rgb = rgb_img[cy:cy+ch, cx:cx+cw]
            results.append({
                'box': (cx, cy, cw, ch),
                'padded_box': (cx, cy, cw, ch),
                'face_img': Image.fromarray(crop_rgb),
                'face_bgr': crop_bgr,
                'is_fallback': True,
                'confidence': 0.70
            })
            return results

        for (x, y, w, h) in faces:
            pad_w = int(w * pad_ratio)
            pad_h = int(h * pad_ratio)

            px1 = max(0, x - pad_w)
            py1 = max(0, y - pad_h)
            px2 = min(width, x + w + pad_w)
            py2 = min(height, y + h + pad_h)

            crop_bgr = bgr_img[py1:py2, px1:px2]
            crop_rgb = rgb_img[py1:py2, px1:px2]

            results.append({
                'box': (int(x), int(y), int(w), int(h)),
                'padded_box': (int(px1), int(py1), int(px2 - px1), int(py2 - py1)),
                'face_img': Image.fromarray(crop_rgb),
                'face_bgr': crop_bgr,
                'is_fallback': False,
                'confidence': 0.95
            })

        return results

    def draw_detections(self, image_np, detections, labels=None):
        annotated = image_np.copy()
        for i, det in enumerate(detections):
            px, py, pw, ph = det['padded_box']
            label = labels[i] if (labels and i < len(labels)) else f"Face #{i+1}"
            color = (0, 0, 255) if "FAKE" in label.upper() else (0, 255, 0)
            
            cv2.rectangle(annotated, (px, py), (px + pw, py + ph), color, 2)
            text_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)[0]
            cv2.rectangle(annotated, (px, max(0, py - 22)), (px + text_size[0] + 8, py), color, -1)
            cv2.putText(annotated, label, (px + 4, max(16, py - 5)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        return annotated
