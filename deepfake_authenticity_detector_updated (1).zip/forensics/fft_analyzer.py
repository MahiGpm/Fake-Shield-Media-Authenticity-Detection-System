"""
Frequency-Domain Spectral Forensics Module (2D Fast Fourier Transform)
Detects periodic upsampling artifacts, checkerboard patterns, and synthetic high-frequency anomalies
characteristic of GANs and diffusion-based deepfake generation models.
"""

import cv2
import numpy as np
from PIL import Image

class FFTAnalyzer:
    def __init__(self, high_freq_cutoff=0.65):
        self.high_freq_cutoff = high_freq_cutoff

    def compute_fft(self, image_input):
        """
        Computes 2D FFT magnitude spectrum and azimuthal radial profile.
        Returns:
            dict containing:
                'spectrum_visual': np.ndarray (colorized spectrum BGR)
                'radial_profile': list of float
                'high_freq_energy': float
                'spectral_anomaly_score': float (0.0 to 1.0)
                'synthetic_artifact_detected': bool
        """
        # Convert to grayscale numpy array
        if isinstance(image_input, Image.Image):
            gray = np.array(image_input.convert('L'), dtype=np.float32)
        elif isinstance(image_input, np.ndarray):
            if len(image_input.shape) == 3:
                gray = cv2.cvtColor(image_input, cv2.COLOR_BGR2GRAY).astype(np.float32)
            else:
                gray = image_input.astype(np.float32)
        else:
            raise ValueError("Unsupported input format for FFT analysis")

        h, w = gray.shape
        # Windowing (Hanning window) to suppress edge boundary leakage
        win_y = np.hanning(h)
        win_x = np.hanning(w)
        window_2d = np.outer(win_y, win_x)
        windowed_gray = gray * window_2d

        # 2D Fast Fourier Transform & Center Shift
        f = np.fft.fft2(windowed_gray)
        fshift = np.fft.fftshift(f)
        magnitude = np.abs(fshift)

        # Log magnitude spectrum for human visualization
        magnitude_spectrum = np.log1p(magnitude)
        norm_spectrum = cv2.normalize(magnitude_spectrum, None, 0, 255, cv2.NORM_MINMAX)
        norm_spectrum_uint8 = norm_spectrum.astype(np.uint8)

        # Colorized spectral visual (Inferno colormap highlights high-frequency spikes)
        spectrum_visual_bgr = cv2.applyColorMap(norm_spectrum_uint8, cv2.COLORMAP_INFERNO)

        # Compute Azimuthal Radial Profile
        cy, cx = h // 2, w // 2
        y, x = np.indices((h, w))
        r = np.sqrt((x - cx) ** 2 + (y - cy) ** 2).astype(np.int32)
        max_r = min(cx, cy)

        radial_sum = np.bincount(r.ravel(), weights=magnitude_spectrum.ravel())
        radial_count = np.bincount(r.ravel())
        radial_count[radial_count == 0] = 1
        radial_profile = (radial_sum / radial_count)[:max_r]

        # Analyze High-Frequency distribution
        cutoff_idx = int(max_r * self.high_freq_cutoff)
        high_freq_band = radial_profile[cutoff_idx:]
        total_energy = np.sum(radial_profile) + 1e-6
        high_freq_ratio = float(np.sum(high_freq_band) / total_energy)

        # Measure high-frequency roughness / periodic spikes:
        # Natural images exhibit smooth exponential decay (low second derivative).
        # GAN images have high variance and ripple in high frequencies.
        if len(high_freq_band) > 4:
            diff2 = np.diff(high_freq_band, n=2)
            roughness = float(np.std(diff2))
        else:
            roughness = 0.0

        # Anomaly score combining high frequency ratio and spectral ripple roughness
        anomaly_score = float(np.clip(2.5 * high_freq_ratio + 1.8 * roughness, 0.0, 1.0))
        synthetic_detected = bool(anomaly_score > 0.50)

        return {
            'spectrum_visual': spectrum_visual_bgr,
            'radial_profile': [round(float(v), 3) for v in radial_profile],
            'high_freq_energy_ratio': round(high_freq_ratio, 4),
            'spectral_roughness': round(roughness, 4),
            'spectral_anomaly_score': round(anomaly_score, 4),
            'synthetic_artifact_detected': synthetic_detected
        }
