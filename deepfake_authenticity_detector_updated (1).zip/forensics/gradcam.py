"""
Explainable AI (XAI) Module: Grad-CAM & Visual Saliency
Produces visual heatmaps highlighting facial manipulation regions (eyes, mouth, seam blending).
"""

import cv2
import numpy as np
import torch
import torch.nn.functional as F

class GradCAMExplainer:
    def __init__(self, model, target_layer):
        """
        Args:
            model: PyTorch model in eval mode
            target_layer: The target convolutional layer (e.g. model.conv4 or model.features[-1])
        """
        self.model = model
        self.target_layer = target_layer
        self.gradients = None
        self.activations = None
        self._register_hooks()

    def _register_hooks(self):
        def forward_hook(module, input, output):
            self.activations = output.detach()

        def backward_hook(module, grad_in, grad_out):
            self.gradients = grad_out[0].detach()

        self.target_layer.register_forward_hook(forward_hook)
        self.target_layer.register_full_backward_hook(backward_hook)

    def generate_heatmap(self, input_tensor, target_class=1):
        """
        Generates Grad-CAM heatmap for the given input tensor.
        Args:
            input_tensor: torch.Tensor of shape (1, C, H, W)
            target_class: Index of target class (1 = Fake)
        Returns:
            np.ndarray: 2D heatmap normalized to [0, 1]
        """
        self.model.zero_grad()
        output = self.model(input_tensor)

        if output.shape[-1] == 1:
            score = output[0, 0]
        else:
            score = output[0, target_class]

        score.backward(retain_graph=True)

        if self.gradients is None or self.activations is None:
            # Fallback to pure activation-based attention
            if self.activations is not None:
                cam = torch.mean(self.activations, dim=1).squeeze().cpu().numpy()
                cam = np.maximum(cam, 0)
                cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
                return cam
            return np.ones((input_tensor.shape[2], input_tensor.shape[3]), dtype=np.float32) * 0.5

        # Global average pooling of gradients
        weights = torch.mean(self.gradients, dim=[2, 3], keepdim=True)
        # Weighted combination of forward activation maps
        cam = torch.sum(weights * self.activations, dim=1).squeeze()
        # Apply ReLU to focus on features that have a positive influence
        cam = F.relu(cam).cpu().numpy()

        # Min-max normalization
        denom = cam.max() - cam.min()
        if denom > 1e-7:
            cam = (cam - cam.min()) / denom
        else:
            cam = np.zeros_like(cam)

        return cam

    @staticmethod
    def overlay_heatmap(orig_rgb_np, heatmap_2d, alpha=0.55):
        """
        Overlays the 2D heatmap onto the original RGB image.
        Returns:
            np.ndarray RGB blended image
        """
        h, w = orig_rgb_np.shape[:2]
        resized_cam = cv2.resize(heatmap_2d, (w, h))
        cam_uint8 = np.uint8(255 * resized_cam)
        heatmap_color = cv2.applyColorMap(cam_uint8, cv2.COLORMAP_JET)
        heatmap_rgb = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)

        blended = cv2.addWeighted(orig_rgb_np, 1.0 - alpha, heatmap_rgb, alpha, 0)
        return blended, heatmap_rgb
