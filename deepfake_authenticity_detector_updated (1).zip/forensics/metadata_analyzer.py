"""
Digital Forensics & Metadata Analysis Module
Extracts EXIF, cryptographic checksums, chunk signatures, and editor traces.
"""

import hashlib
import os
from PIL import Image
from PIL.ExifTags import TAGS

class MetadataAnalyzer:
    def __init__(self):
        self.known_ai_signatures = [
            "stable diffusion", "midjourney", "dall-e", "comfyui", "novelai",
            "adobe firefly", "deepfacelab", "faceapp", "photoshop", "gimp",
            "replicate", "runway", "pika", "sora"
        ]

    def analyze(self, file_path_or_bytes, filename="media_sample"):
        """
        Analyzes file metadata, cryptographic hashes, and EXIF attributes.
        Returns:
            dict containing metadata properties and tamper risk score.
        """
        results = {
            'filename': os.path.basename(filename),
            'filesize_kb': 0,
            'md5': '',
            'sha256': '',
            'dimensions': (0, 0),
            'format': 'UNKNOWN',
            'exif_present': False,
            'exif_tags': {},
            'suspicious_software': None,
            'metadata_risk_score': 0.10,
            'findings': []
        }

        # Handle path vs bytes
        if isinstance(file_path_or_bytes, (str, os.PathLike)):
            with open(file_path_or_bytes, 'rb') as f:
                raw_bytes = f.read()
            results['filesize_kb'] = round(len(raw_bytes) / 1024.0, 2)
        elif isinstance(file_path_or_bytes, bytes):
            raw_bytes = file_path_or_bytes
            results['filesize_kb'] = round(len(raw_bytes) / 1024.0, 2)
        else:
            return results

        # Cryptographic hashes for chain of custody
        results['md5'] = hashlib.md5(raw_bytes).hexdigest()
        results['sha256'] = hashlib.sha256(raw_bytes).hexdigest()

        # Image analysis
        import io
        try:
            with Image.open(io.BytesIO(raw_bytes)) as img:
                results['dimensions'] = img.size
                results['format'] = img.format or 'UNKNOWN'

                # Raw PNG text chunk check (ComfyUI / A1111 embed generation parameters)
                if hasattr(img, 'text') and img.text:
                    for k, v in img.text.items():
                        v_lower = str(v).lower()
                        if any(sig in v_lower for sig in self.known_ai_signatures):
                            results['suspicious_software'] = f"Embedded AI metadata: {k}"
                            results['metadata_risk_score'] = 0.95
                            results['findings'].append(f"AI Generation prompt/seed detected in PNG metadata [{k}]")

                # EXIF inspection
                info = img._getexif()
                if info:
                    results['exif_present'] = True
                    for tag_id, value in info.items():
                        tag_name = TAGS.get(tag_id, str(tag_id))
                        results['exif_tags'][tag_name] = str(value)[:120]

                        # Check Software tag
                        if tag_name.lower() == 'software':
                            val_str = str(value).lower()
                            for sig in self.known_ai_signatures:
                                if sig in val_str:
                                    results['suspicious_software'] = str(value)
                                    results['metadata_risk_score'] = max(results['metadata_risk_score'], 0.90)
                                    results['findings'].append(f"Known synthetic editor software tag found: {value}")
                else:
                    # Lack of EXIF in high-res camera-like photo is a mild suspicious indicator
                    if results['dimensions'][0] > 1024 and results['dimensions'][1] > 1024:
                        results['metadata_risk_score'] = max(results['metadata_risk_score'], 0.35)
                        results['findings'].append("Cleaned / Stripped EXIF metadata (Typical of synthetic outputs or web re-uploads)")

        except Exception as e:
            results['findings'].append(f"Metadata parsing note: {str(e)}")

        return results
