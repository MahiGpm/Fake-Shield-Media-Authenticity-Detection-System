"""
Temporal Video Forensics Module
Analyzes frame-to-frame temporal coherence, flicker variance, and identifies manipulated video segments.
"""

import cv2
import numpy as np

class TemporalAnalyzer:
    def __init__(self, sample_interval=5, max_frames=90):
        self.sample_interval = sample_interval
        self.max_frames = max_frames

    def extract_video_frames(self, video_path):
        """
        Extracts sampled frames from a video file with timestamp metadata.
        Returns:
            list of dict: [{'frame_idx': int, 'time_sec': float, 'frame_bgr': np.ndarray, 'frame_rgb': np.ndarray}, ...]
            dict video_metadata: {'fps': float, 'total_frames': int, 'duration_sec': float, 'width': int, 'height': int}
        """
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            raise IOError(f"Unable to open video source: {video_path}")

        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        duration_sec = total_frames / fps if fps > 0 else 0

        metadata = {
            'fps': round(fps, 2),
            'total_frames': total_frames,
            'duration_sec': round(duration_sec, 2),
            'width': width,
            'height': height
        }

        # Calculate dynamic step if video has many frames
        step = self.sample_interval
        if total_frames > 0 and (total_frames // step) > self.max_frames:
            step = max(1, total_frames // self.max_frames)

        extracted_frames = []
        frame_idx = 0

        while cap.isOpened() and len(extracted_frames) < self.max_frames:
            ret, frame = cap.read()
            if not ret:
                break

            if frame_idx % step == 0:
                time_sec = frame_idx / fps
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                extracted_frames.append({
                    'frame_idx': frame_idx,
                    'time_sec': round(time_sec, 2),
                    'frame_bgr': frame,
                    'frame_rgb': frame_rgb
                })

            frame_idx += 1

        cap.release()
        return extracted_frames, metadata

    def analyze_timeline(self, frame_scores):
        """
        Aggregates frame-by-frame scores into temporal statistics, identifies anomalous segments.
        Args:
            frame_scores: list of dict [{'time_sec': float, 'frame_idx': int, 'fake_prob': float}, ...]
        Returns:
            dict with temporal stability metrics and flagged segments.
        """
        if not frame_scores:
            return {
                'overall_video_fake_prob': 0.0,
                'temporal_variance': 0.0,
                'manipulated_segments': [],
                'verdict': 'INCONCLUSIVE'
            }

        probs = np.array([f['fake_prob'] for f in frame_scores])
        times = [f['time_sec'] for f in frame_scores]

        mean_prob = float(np.mean(probs))
        max_prob = float(np.max(probs))
        var_prob = float(np.var(probs))
        flicker_score = float(np.mean(np.abs(np.diff(probs)))) if len(probs) > 1 else 0.0

        # Video manipulation score:
        # Heavily accounts for localized spikes (e.g., deepfake face inserted in a specific section)
        # plus temporal flicker penalty
        aggregated_score = float(np.clip(
            0.55 * max_prob + 0.35 * mean_prob + 0.10 * min(1.0, flicker_score * 3.0),
            0.0, 1.0
        ))

        # Identify contiguous manipulated time windows
        manipulated_segments = []
        in_segment = False
        seg_start = 0.0

        for f in frame_scores:
            if f['fake_prob'] >= 0.50 and not in_segment:
                in_segment = True
                seg_start = f['time_sec']
            elif f['fake_prob'] < 0.50 and in_segment:
                in_segment = False
                manipulated_segments.append({
                    'start_sec': seg_start,
                    'end_sec': f['time_sec'],
                    'duration_sec': round(f['time_sec'] - seg_start, 2)
                })

        if in_segment and frame_scores:
            manipulated_segments.append({
                'start_sec': seg_start,
                'end_sec': times[-1],
                'duration_sec': round(times[-1] - seg_start, 2)
            })

        verdict = "DEEPFAKE DETECTED" if aggregated_score >= 0.50 else "AUTHENTIC MEDIA"
        confidence_level = "HIGH" if aggregated_score >= 0.75 or aggregated_score <= 0.25 else "MODERATE"

        return {
            'overall_video_fake_prob': round(aggregated_score, 4),
            'mean_frame_fake_prob': round(mean_prob, 4),
            'peak_frame_fake_prob': round(max_prob, 4),
            'temporal_variance': round(var_prob, 5),
            'temporal_flicker_score': round(flicker_score, 4),
            'manipulated_segments': manipulated_segments,
            'verdict': verdict,
            'confidence_level': confidence_level
        }
