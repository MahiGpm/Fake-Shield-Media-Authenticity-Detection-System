import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Dropzone from './components/Dropzone';
import AnalysisResult from './components/AnalysisResult';
import HistoryTable from './components/HistoryTable';
import ModelInfoModal from './components/ModelInfoModal';
import { AlertCircle, ShieldCheck, CheckCircle2 } from 'lucide-react';

const API_BASE = '/api';

export default function App() {
  const [activeTab, setActiveTab] = useState('detect'); // 'detect' | 'history'
  const [systemHealth, setSystemHealth] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isModelInfoOpen, setIsModelInfoOpen] = useState(false);

  // Fetch health check on mount
  useEffect(() => {
    checkHealth();
    fetchHistory();
  }, []);

  const checkHealth = async () => {
    try {
      const res = await fetch(`${API_BASE}/health`);
      if (res.ok) {
        const data = await res.json();
        setSystemHealth(data);
      } else {
        setSystemHealth({ status: 'offline', model_ready: false });
      }
    } catch (err) {
      setSystemHealth({ status: 'offline', model_ready: false });
    }
  };

  const fetchHistory = async () => {
    setIsHistoryLoading(true);
    try {
      const res = await fetch(`${API_BASE}/history`);
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch (err) {
      console.error('Failed to load history:', err);
    } finally {
      setIsHistoryLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (!window.confirm('Are you sure you want to clear all analysis audit records?')) return;
    try {
      const res = await fetch(`${API_BASE}/history`, { method: 'DELETE' });
      if (res.ok) {
        setHistory([]);
      }
    } catch (err) {
      setErrorMessage('Failed to clear history: ' + err.message);
    }
  };

  const handleFileAnalysis = async (file) => {
    if (!file) return;
    setIsAnalyzing(true);
    setErrorMessage('');
    setAnalysisResult(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const ext = '.' + file.name.split('.').pop().toLowerCase();
      const videoExts = ['.mp4', '.mov', '.avi', '.mkv', '.webm'];
      const endpoint = videoExts.includes(ext) ? '/analyze/video' : '/analyze';
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        let errText = 'Server analysis error';
        try {
          const errData = await res.json();
          errText = errData.detail || errText;
        } catch {
          errText = `HTTP Error ${res.status}: ${res.statusText}`;
        }
        throw new Error(errText);
      }

      const resultData = await res.json();
      setAnalysisResult(resultData);
      // Refresh history list in background
      fetchHistory();
    } catch (err) {
      setErrorMessage(err.message || 'An unexpected error occurred during model inference.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setAnalysisResult(null);
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    setErrorMessage('');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-white">
      {/* Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'history') fetchHistory();
        }}
        systemHealth={systemHealth}
        onOpenModelInfo={() => setIsModelInfoOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Error Alert Banner */}
        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 flex items-start justify-between space-x-3 animate-in fade-in">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-rose-200 text-sm">Forensic Inspection Error</h4>
                <p className="text-xs text-rose-300/90 mt-0.5">{errorMessage}</p>
              </div>
            </div>
            <button
              onClick={() => setErrorMessage('')}
              className="text-xs text-rose-400 hover:text-white font-mono"
            >
              [Dismiss]
            </button>
          </div>
        )}

        {/* Tab 1: Inspector / Detect View */}
        {activeTab === 'detect' && (
          <div className="space-y-8">
            {/* Hero Subtitle */}
            {!analysisResult && (
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                  Media Authenticity & Deepfake Forensic Engine
                </h1>
                <p className="text-sm text-slate-400">
                  Real-time facial manipulation detection powered by Vision Transformer (ViT-Base) deep learning, Error Level Analysis (ELA), and cryptographic SQLite audit logging.
                </p>
              </div>
            )}

            {/* Analysis Result or Dropzone */}
            {analysisResult ? (
              <AnalysisResult
                result={analysisResult}
                onReset={handleReset}
                onViewHistory={() => {
                  setActiveTab('history');
                  fetchHistory();
                }}
              />
            ) : (
              <div className="max-w-2xl mx-auto">
                <Dropzone
                  onFileSelected={handleFileAnalysis}
                  isAnalyzing={isAnalyzing}
                  selectedFile={selectedFile}
                  setSelectedFile={setSelectedFile}
                  previewUrl={previewUrl}
                  setPreviewUrl={setPreviewUrl}
                />
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Audit History View */}
        {activeTab === 'history' && (
          <HistoryTable
            history={history}
            isLoading={isHistoryLoading}
            onRefresh={fetchHistory}
            onClearHistory={handleClearHistory}
            onSelectRecord={(rec) => {
              setAnalysisResult(rec);
              setActiveTab('detect');
            }}
          />
        )}
      </main>

      {/* Model Info Modal */}
      <ModelInfoModal
        isOpen={isModelInfoOpen}
        onClose={() => setIsModelInfoOpen(false)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/40 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>VeriFace AI | Final Year Engineering Project: Deepfake Media Authenticity Detection System</span>
          <span className="font-mono text-slate-400">PyTorch • ViT-Base • FastAPI • React • SQLite</span>
        </div>
      </footer>
    </div>
  );
}
