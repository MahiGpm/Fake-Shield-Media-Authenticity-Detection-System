import React from 'react';
import {
  ShieldAlert, ShieldCheck, Cpu, Clock, AlertTriangle,
  RotateCcw, FileText, CheckCircle, HelpCircle, HardDrive, Zap
} from 'lucide-react';

export default function AnalysisResult({ result, onReset, onViewHistory }) {
  if (!result) return null;

  const isFake = result.predicted_class === 'FAKE';
  const isDemo = result.is_demo_mode;
  const confidencePct = (result.confidence_score * 100).toFixed(1);
  const realPct = ((result.real_probability || (isFake ? 1 - result.confidence_score : result.confidence_score)) * 100).toFixed(1);
  const fakePct = ((result.fake_probability || (isFake ? result.confidence_score : 1 - result.confidence_score)) * 100).toFixed(1);

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-300">
      {/* Demo Mode Notice Banner (if active) */}
      {isDemo && (
        <div className="p-4 rounded-xl bg-amber-950/60 border border-amber-600/70 text-amber-200 text-sm flex items-start space-x-3">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-amber-300">LABELED DEMO FALLBACK ACTIVE</h4>
            <p className="text-xs text-amber-200/90 mt-0.5">
              Notice: The backend is operating in offline demonstration mode. This result is a mock demonstration and MUST NOT be treated as a real AI prediction.
            </p>
          </div>
        </div>
      )}

      {/* Main Verdict Card */}
      <div
        className={`p-6 sm:p-8 rounded-2xl border transition-all shadow-xl ${
          isFake
            ? 'bg-gradient-to-b from-rose-950/40 via-slate-900/80 to-slate-900 border-rose-800/60 shadow-rose-950/30'
            : 'bg-gradient-to-b from-emerald-950/40 via-slate-900/80 to-slate-900 border-emerald-800/60 shadow-emerald-950/30'
        }`}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          {/* Verdict Text & Badge */}
          <div className="flex items-start sm:items-center space-x-4">
            <div
              className={`p-4 rounded-2xl shrink-0 shadow-lg ${
                isFake
                  ? 'bg-rose-600/20 text-rose-400 border border-rose-500/30 shadow-rose-600/20'
                  : 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 shadow-emerald-600/20'
              }`}
            >
              {isFake ? <ShieldAlert className="h-10 w-10" /> : <ShieldCheck className="h-10 w-10" />}
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <span
                  className={`text-xs uppercase tracking-wider font-bold px-2.5 py-0.5 rounded-full ${
                    isFake ? 'bg-rose-950 text-rose-400 border border-rose-800' : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  }`}
                >
                  Forensic Verdict
                </span>
                <span className="text-xs text-slate-400">ID #{result.id}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 tracking-tight">
                {isFake ? 'DEEPFAKE DETECTED' : 'AUTHENTIC MEDIA'}
              </h2>

              <p className="text-sm text-slate-300 mt-1 max-w-xl">
                {result.media_type === 'video'
                  ? 'This verdict combines predictions from uniformly sampled video frames. It does not inspect every frame or audio track.'
                  : (isFake
                    ? 'The image classifier found patterns associated with manipulated or synthetic imagery.'
                    : 'The image classifier found patterns more consistent with its real-image class. This does not prove authenticity.')}
              </p>
            </div>
          </div>

          {/* Confidence Score Gauge */}
          <div className="flex flex-col items-start md:items-end bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 shrink-0">
            <span className="text-xs text-slate-400 font-medium">Model Confidence</span>
            <div className="flex items-baseline space-x-1 mt-0.5">
              <span className={`text-4xl font-black font-mono tracking-tight ${isFake ? 'text-rose-400' : 'text-emerald-400'}`}>
                {confidencePct}%
              </span>
            </div>
            <span className="text-xs text-slate-400 mt-0.5">
              Predicted: <strong className="text-slate-200">{result.predicted_class}</strong>
            </span>
          </div>
        </div>

        {/* Probability Dual Bar */}
        <div className="mt-6 pt-6 border-t border-slate-800/80">
          <div className="flex justify-between text-xs text-slate-400 mb-1.5 font-medium">
            <span className="flex items-center space-x-1">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span>Real Probability: {realPct}%</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="h-2 w-2 rounded-full bg-rose-400" />
              <span>Fake Probability: {fakePct}%</span>
            </span>
          </div>

          <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden flex p-0.5">
            <div
              style={{ width: `${realPct}%` }}
              className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-l-full transition-all duration-500"
            />
            <div
              style={{ width: `${fakePct}%` }}
              className="h-full bg-gradient-to-r from-rose-500 to-rose-400 rounded-r-full transition-all duration-500"
            />
          </div>
        </div>
      </div>

      {/* Forensic Diagnostics & Evidence Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Model Name */}
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center space-x-2 text-slate-400 text-xs mb-1">
            <Cpu className="h-4 w-4 text-cyan-400" />
            <span>AI Architecture</span>
          </div>
          <p className="font-semibold text-slate-200 text-sm truncate" title={result.model_name}>
            {result.model_name}
          </p>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            {result.architecture || 'ViT-Base / Patch16'}
          </p>
        </div>

        {/* Metric 2: Processing Latency */}
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center space-x-2 text-slate-400 text-xs mb-1">
            <Clock className="h-4 w-4 text-cyan-400" />
            <span>Inference Latency</span>
          </div>
          <p className="font-semibold text-slate-200 text-sm font-mono">
            {result.processing_time_ms} ms
          </p>
          <p className="text-xs text-slate-400 mt-1 flex items-center space-x-1">
            <Zap className="h-3 w-3 text-emerald-400" />
            <span>Device: {result.device_used || 'CPU'}</span>
          </p>
        </div>

        {/* Metric 3: Media File Specs */}
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center space-x-2 text-slate-400 text-xs mb-1">
            <HardDrive className="h-4 w-4 text-cyan-400" />
            <span>Target Media</span>
          </div>
          <p className="font-semibold text-slate-200 text-sm truncate" title={result.filename}>
            {result.filename}
          </p>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            {result.media_type === 'video'
              ? `${result.image_width}x${result.image_height} px • ${result.duration_sec ?? 'N/A'} sec • ${result.frames_analyzed ?? 0}/${result.total_frames ?? 0} frames sampled`
              : `${result.image_width}x${result.image_height} px • ${result.filesize_kb} KB`}
          </p>
        </div>

        {/* Metric 4: ELA Compression */}
        <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center space-x-2 text-slate-400 text-xs mb-1">
            <CheckCircle className="h-4 w-4 text-cyan-400" />
            <span>ELA Compression Score</span>
          </div>
          <p className="font-semibold text-slate-200 text-sm font-mono">
            {result.ela_score ? `${(result.ela_score * 100).toFixed(1)}% Anomaly` : 'N/A'}
          </p>
          <p className="text-xs text-slate-400 mt-1">
            {result.ela_score > 0.5 ? 'Suspicious error level' : 'Uniform compression'}
          </p>
        </div>
      </div>

      {result.media_type === 'video' && Array.isArray(result.frame_results) && (
        <section className="bg-slate-900/60 border border-slate-800 p-5 rounded-xl">
          <h3 className="text-white font-semibold mb-3">Video frame analysis</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <div className="rounded-lg bg-slate-950 p-3"><p className="text-xs text-slate-400">Mean fake score</p><p className="text-lg font-mono text-slate-100">{(100 * (result.mean_fake_probability ?? 0)).toFixed(1)}%</p></div>
            <div className="rounded-lg bg-slate-950 p-3"><p className="text-xs text-slate-400">Peak frame score</p><p className="text-lg font-mono text-slate-100">{(100 * (result.peak_fake_probability ?? 0)).toFixed(1)}%</p></div>
            <div className="rounded-lg bg-slate-950 p-3"><p className="text-xs text-slate-400">Frames over threshold</p><p className="text-lg font-mono text-slate-100">{result.manipulated_frames_count ?? 0}</p></div>
            <div className="rounded-lg bg-slate-950 p-3"><p className="text-xs text-slate-400">Peak timestamp</p><p className="text-lg font-mono text-slate-100">{result.peak_timestamp_sec ?? 'N/A'} s</p></div>
          </div>
          <div className="max-h-64 overflow-auto space-y-2">
            {result.frame_results.map((frame) => (
              <div key={frame.frame_index} className="grid grid-cols-[70px_1fr_70px] gap-3 items-center text-xs">
                <span className="text-slate-400">{frame.timestamp_sec ?? '—'} s</span>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden"><div className={`h-full ${frame.fake_probability >= 0.5 ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{ width: `${Math.max(0, Math.min(100, frame.fake_probability * 100))}%` }} /></div>
                <span className="text-right text-slate-300">{(frame.fake_probability * 100).toFixed(1)}%</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-amber-300 mt-3">Frame scores and the combined score are screening indicators, not calibrated proof. Unsampled frames can contain manipulations.</p>
        </section>
      )}

      {/* Evidentiary Preview & Limitations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Image Preview */}
        {result.preview_base64 && (
          <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl flex flex-col items-center">
            <span className="text-xs font-semibold text-slate-400 mb-3 self-start">
              Audited Media Snapshot
            </span>
            <div className="relative rounded-lg overflow-hidden border border-slate-700 shadow-md">
              <img
                src={result.preview_base64}
                alt="Audited media"
                className="w-48 h-48 object-cover"
              />
              <span
                className={`absolute bottom-2 right-2 text-xs font-mono font-bold px-2 py-0.5 rounded shadow ${
                  isFake ? 'bg-rose-900/90 text-rose-200' : 'bg-emerald-900/90 text-emerald-200'
                }`}
              >
                {result.predicted_class}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-2 text-center">
              SHA Checksum registered in SQLite history
            </p>
          </div>
        )}

        {/* Limitations & Ethical Disclaimer (Required Feature) */}
        <div className={`p-5 rounded-xl border bg-slate-900/40 border-slate-800 ${result.preview_base64 ? 'lg:col-span-2' : 'lg:col-span-3'}`}>
          <div className="flex items-center space-x-2 text-cyan-400 mb-2">
            <HelpCircle className="h-4 w-4" />
            <h4 className="text-sm font-semibold text-white">System Limitations & Evidentiary Scope</h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {result.limitations}
          </p>
          <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs text-slate-400">
            <strong>Academic Note:</strong> Deepfake detection models are probabilistic classifiers. For legal and forensic audits, AI predictions should always be corroborated with physical metadata and Error Level Analysis (ELA).
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
        <button
          type="button"
          onClick={onReset}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition-colors flex items-center space-x-2 border border-slate-700"
        >
          <RotateCcw className="h-4 w-4" />
          <span>Analyze Another Media</span>
        </button>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onViewHistory}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition-colors flex items-center space-x-2 border border-slate-700"
          >
            <FileText className="h-4 w-4 text-cyan-400" />
            <span>View Full Audit History</span>
          </button>
        </div>
      </div>
    </div>
  );
}
