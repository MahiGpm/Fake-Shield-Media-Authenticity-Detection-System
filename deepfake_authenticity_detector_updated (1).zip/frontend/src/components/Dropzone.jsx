import React, { useState, useRef } from 'react';
import { UploadCloud, Image as ImageIcon, AlertCircle, Sparkles, CheckCircle2, X } from 'lucide-react';

const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp'];
const VIDEO_EXTENSIONS = ['.mp4', '.mov', '.avi', '.mkv', '.webm'];
const MAX_IMAGE_SIZE_MB = 15;
const MAX_VIDEO_SIZE_MB = 100;

export default function Dropzone({ onFileSelected, isAnalyzing, selectedFile, setSelectedFile, previewUrl, setPreviewUrl }) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const fileInputRef = useRef(null);

  const validateAndSetFile = (file) => {
    setErrorMessage('');
    if (!file) return;

    // Check extension
    const ext = '.' + file.name.split('.').pop().toLowerCase();
    const isImage = IMAGE_EXTENSIONS.includes(ext);
    const isVideo = VIDEO_EXTENSIONS.includes(ext);
    if (!isImage && !isVideo) {
      setErrorMessage(`Unsupported format '${ext}'. Upload JPG, PNG, WEBP, MP4, MOV, AVI, MKV, or WEBM.`);
      return;
    }

    const maxSizeMb = isVideo ? MAX_VIDEO_SIZE_MB : MAX_IMAGE_SIZE_MB;
    if (file.size > maxSizeMb * 1024 * 1024) {
      setErrorMessage(`File size (${(file.size / (1024 * 1024)).toFixed(1)} MB) exceeds ${maxSizeMb} MB limit.`);
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleInputChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleClear = (e) => {
    e.stopPropagation();
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    setErrorMessage('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const loadBenchmarkSample = async (type) => {
    try {
      setErrorMessage('');
      // Generate synthetic sample on canvas to test client-side immediately
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d');

      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, 256, 256);
      grad.addColorStop(0, type === 'fake' ? '#2A1B3D' : '#1A293D');
      grad.addColorStop(1, type === 'fake' ? '#44318D' : '#234E52');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 256, 256);

      // Face silhouette
      ctx.fillStyle = type === 'fake' ? '#ECC94B' : '#ED8936';
      ctx.beginPath();
      ctx.arc(128, 128, 70, 0, Math.PI * 2);
      ctx.fill();

      // Eyes
      ctx.fillStyle = '#1A202C';
      ctx.beginPath();
      ctx.arc(105, 115, 10, 0, Math.PI * 2);
      ctx.arc(151, 115, 10, 0, Math.PI * 2);
      ctx.fill();

      // Mouth
      ctx.beginPath();
      ctx.arc(128, 155, 25, 0.2 * Math.PI, 0.8 * Math.PI, false);
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#1A202C';
      ctx.stroke();

      if (type === 'fake') {
        // Draw synthetic checkerboard grid artifacts on fake sample
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        for (let i = 0; i < 256; i += 16) {
          for (let j = 0; j < 256; j += 16) {
            if ((i + j) % 32 === 0) {
              ctx.fillRect(i, j, 8, 8);
            }
          }
        }
      }

      canvas.toBlob((blob) => {
        const testFile = new File([blob], `benchmark_${type}_sample.jpg`, { type: 'image/jpeg' });
        validateAndSetFile(testFile);
      }, 'image/jpeg', 0.92);
    } catch (err) {
      setErrorMessage('Failed to generate benchmark sample: ' + err.message);
    }
  };

  return (
    <div className="w-full">
      {/* Upload Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !isAnalyzing && fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-10 transition-all cursor-pointer flex flex-col items-center justify-center text-center ${
          isDragOver
            ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-500/10'
            : selectedFile
            ? 'border-slate-700 bg-slate-900/40 hover:border-slate-600'
            : 'border-slate-700 bg-slate-900/60 hover:border-slate-600 hover:bg-slate-900/80'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".jpg,.jpeg,.png,.webp,.mp4,.mov,.avi,.mkv,.webm"
          onChange={handleInputChange}
          className="hidden"
          disabled={isAnalyzing}
        />

        {selectedFile && previewUrl ? (
          /* Image Selected Preview */
          <div className="flex flex-col items-center w-full max-w-sm">
            <div className="relative group">
              {VIDEO_EXTENSIONS.includes('.' + selectedFile.name.split('.').pop().toLowerCase()) ? (
                <video
                  src={previewUrl}
                  controls
                  className="w-full max-w-md max-h-64 rounded-xl border border-slate-700 shadow-xl"
                />
              ) : (
                <img
                  src={previewUrl}
                  alt="Selected Preview"
                  className="w-48 h-48 sm:w-56 sm:h-56 object-cover rounded-xl border border-slate-700 shadow-xl"
                />
              )}
              <button
                type="button"
                onClick={handleClear}
                disabled={isAnalyzing}
                className="absolute -top-2 -right-2 p-1.5 bg-rose-600 text-white rounded-full hover:bg-rose-500 shadow-md transition-colors"
                title="Remove image"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 text-center">
              <div className="flex items-center justify-center space-x-1.5 text-slate-200 font-medium text-sm truncate max-w-xs">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span className="truncate">{selectedFile.name}</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {(selectedFile.size / 1024).toFixed(1)} KB • {selectedFile.type.toUpperCase()}
              </p>
            </div>

            <p className="text-xs text-slate-400 mt-2">
              Click anywhere or drag a new image to replace
            </p>
          </div>
        ) : (
          /* Empty Dropzone State */
          <div className="flex flex-col items-center max-w-md">
            <div className="h-16 w-16 rounded-2xl bg-cyan-950/60 border border-cyan-800/40 flex items-center justify-center mb-4 text-cyan-400">
              <UploadCloud className="h-8 w-8" />
            </div>

            <h3 className="text-lg font-semibold text-white mb-1">
              Drag & Drop an image or video here
            </h3>
            <p className="text-sm text-slate-400 mb-4">
              or click to browse from your device
            </p>

            <div className="flex flex-wrap items-center justify-center gap-1.5 text-xs text-slate-400">
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono">JPG</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono">JPEG</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono">PNG</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono">WEBP</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono">MP4 / MOV / AVI</span>
              <span className="text-slate-400">• Images 15 MB • Videos 100 MB</span>
            </div>
          </div>
        )}
      </div>

      {/* Error Callout */}
      {errorMessage && (
        <div className="mt-3 p-3 rounded-xl bg-rose-950/50 border border-rose-800/60 text-rose-300 text-sm flex items-start space-x-2">
          <AlertCircle className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Action Controls & Sample Benchmarks */}
      <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span>Quick Viva Demo:</span>
          <button
            type="button"
            onClick={() => loadBenchmarkSample('real')}
            disabled={isAnalyzing}
            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:text-white transition-colors"
          >
            Sample Authentic
          </button>
          <button
            type="button"
            onClick={() => loadBenchmarkSample('fake')}
            disabled={isAnalyzing}
            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:text-white transition-colors"
          >
            Sample Deepfake
          </button>
        </div>

        <button
          type="button"
          onClick={() => selectedFile && onFileSelected(selectedFile)}
          disabled={!selectedFile || isAnalyzing}
          className={`w-full sm:w-auto px-6 py-2.5 rounded-xl font-medium text-sm flex items-center justify-center space-x-2 shadow-lg transition-all ${
            !selectedFile || isAnalyzing
              ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
              : 'bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-cyan-500/25 active:scale-[0.98]'
          }`}
        >
          {isAnalyzing ? (
            <>
              <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Analyzing media frames...</span>
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" />
              <span>Verify Authenticity</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
