import React, { useState } from 'react';
import { History, Trash2, RefreshCw, Search, ShieldAlert, ShieldCheck, AlertTriangle, ExternalLink } from 'lucide-react';

export default function HistoryTable({ history, isLoading, onRefresh, onClearHistory, onSelectRecord }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('ALL');

  const filteredHistory = history.filter((item) => {
    const matchesSearch = item.filename.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = filterClass === 'ALL' || item.predicted_class === filterClass;
    return matchesSearch && matchesClass;
  });

  return (
    <div className="w-full bg-slate-900/60 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <History className="h-5 w-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-white tracking-tight">
              SQLite Audit History
            </h3>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
              {history.length} records
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Cryptographically persisted digital forensics verification records.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Refresh History"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            type="button"
            onClick={onClearHistory}
            disabled={isLoading || history.length === 0}
            className="px-3 py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-medium flex items-center space-x-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear History</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by filename..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center space-x-1.5 self-start sm:self-auto text-xs">
          {['ALL', 'REAL', 'FAKE'].map((cls) => (
            <button
              key={cls}
              type="button"
              onClick={() => setFilterClass(cls)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                filterClass === cls
                  ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cls}
            </button>
          ))}
        </div>
      </div>

      {/* History Table */}
      {filteredHistory.length === 0 ? (
        <div className="py-12 text-center text-slate-400 text-sm">
          <p>No audit records found.</p>
          <p className="text-xs text-slate-400 mt-1">
            Analyze an image in the Inspector tab to create a persistent forensic log.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">#ID</th>
                <th className="py-3 px-4">Filename</th>
                <th className="py-3 px-4">Resolution</th>
                <th className="py-3 px-4">Verdict</th>
                <th className="py-3 px-4">Confidence</th>
                <th className="py-3 px-4">Latency</th>
                <th className="py-3 px-4">Engine</th>
                <th className="py-3 px-4">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
              {filteredHistory.map((row) => {
                const isFake = row.predicted_class === 'FAKE';
                const isDemo = Boolean(row.is_demo_mode);
                return (
                  <tr
                    key={row.id}
                    onClick={() => onSelectRecord && onSelectRecord(row)}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4 text-slate-400">#{row.id}</td>
                    <td className="py-3 px-4 font-sans font-medium text-white max-w-xs truncate" title={row.filename}>
                      {row.filename}
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {row.image_width}x{row.image_height}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-semibold ${
                          isFake
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        }`}
                      >
                        {isFake ? <ShieldAlert className="h-3 w-3" /> : <ShieldCheck className="h-3 w-3" />}
                        <span>{row.predicted_class}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold">
                      <span className={isFake ? 'text-rose-400' : 'text-emerald-400'}>
                        {(row.confidence_score * 100).toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {row.processing_time_ms} ms
                    </td>
                    <td className="py-3 px-4">
                      {isDemo ? (
                        <span className="text-amber-400 text-xs flex items-center space-x-1">
                          <AlertTriangle className="h-3 w-3" />
                          <span>Demo</span>
                        </span>
                      ) : (
                        <span className="text-cyan-400 text-xs">ViT-Base</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-400 text-xs font-sans">
                      {row.created_at || 'Just now'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
