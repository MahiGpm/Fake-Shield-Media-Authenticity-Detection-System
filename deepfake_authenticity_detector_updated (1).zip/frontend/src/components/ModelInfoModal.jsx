import React from 'react';
import { X, Cpu, Shield, Database, ExternalLink, AlertCircle, Award } from 'lucide-react';

export default function ModelInfoModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800/60">
              <Cpu className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">
                Pretrained Model Technical Specifications
              </h3>
              <p className="text-xs text-slate-400">
                Vision Transformer (ViT-Base) Image Deepfake Classifier
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Specs Table */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-slate-400 font-medium">HuggingFace Model ID</span>
            <p className="font-mono text-cyan-300 font-semibold mt-0.5 truncate">
              dima806/deepfake_vs_real_image_detection
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-slate-400 font-medium">Base Architecture</span>
            <p className="text-slate-200 font-semibold mt-0.5">
              ViT-Base / Patch16 (86M Parameters)
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-slate-400 font-medium">Training Dataset Provenance</span>
            <p className="text-slate-200 font-semibold mt-0.5">
              140k+ Real & Deepfake Faces (FaceForensics++)
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-slate-400 font-medium">Open Source License</span>
            <p className="text-emerald-400 font-semibold mt-0.5">
              Apache 2.0 (Permissive Academic & Commercial)
            </p>
          </div>
        </div>

        {/* Architecture Details */}
        <div className="space-y-2 text-xs text-slate-300 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
          <h4 className="font-semibold text-white flex items-center space-x-1.5">
            <Shield className="h-4 w-4 text-cyan-400" />
            <span>How ViT Deepfake Detection Works</span>
          </h4>
          <p className="leading-relaxed text-slate-300">
            Unlike standard Convolutional Neural Networks (CNNs) that rely strictly on local receptive fields, Vision Transformers divide an image into 16x16 pixel patches and utilize Multi-Head Self-Attention to capture long-range contextual dependencies across facial landmarks. Generative deepfakes (FaceSwap, DeepFaceLab, StyleGAN) frequently introduce subtle boundary blending inconsistencies and unnatural high-frequency micro-textures that ViT self-attention heads detect with high sensitivity.
          </p>
        </div>

        {/* Limitations Callout */}
        <div className="space-y-1.5 text-xs text-rose-300/90 bg-rose-950/30 p-4 rounded-xl border border-rose-900/50">
          <h4 className="font-semibold text-rose-300 flex items-center space-x-1.5">
            <AlertCircle className="h-4 w-4 text-rose-400" />
            <span>Critical Model Limitations & Disclaimers</span>
          </h4>
          <ul className="list-disc pl-4 space-y-1 text-xs">
            <li>Trained on human faces; non-facial media (landscapes, objects) may produce inconclusive scores.</li>
            <li>Low-resolution inputs (&lt;128px) or extreme recompression (e.g. repeated WhatsApp/WeChat compression) can obscure subtle AI blending artifacts.</li>
            <li>New generative diffusion paradigms (Flux, Midjourney v6) may exhibit different synthetic signatures than GANs.</li>
            <li>Never use automated AI classifier scores as sole evidence in legal proceedings without forensic human corroboration.</li>
          </ul>
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium transition-colors"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
}
