import React from 'react';
import { ShieldCheck, Cpu, Database, Info, History, Layers } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, systemHealth, onOpenModelInfo }) {
  return (
    <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('detect')}>
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <ShieldCheck className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight text-white">VeriFace AI</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  Forensics v1.0
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Deepfake Media Authenticity Detection System
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center space-x-1 sm:space-x-2">
            <button
              onClick={() => setActiveTab('detect')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'detect'
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Layers className="h-4 w-4" />
              <span>Inspector</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'history'
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <History className="h-4 w-4" />
              <span>Audit History</span>
            </button>

            <button
              onClick={onOpenModelInfo}
              className="px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 transition-colors flex items-center space-x-1.5"
            >
              <Info className="h-4 w-4 text-slate-400" />
              <span className="hidden md:inline">Model Info</span>
            </button>
          </nav>

          {/* System Health Pill */}
          <div className="hidden lg:flex items-center space-x-3 text-xs">
            <div className="flex items-center space-x-2 bg-slate-950/70 border border-slate-800 px-3 py-1.5 rounded-full">
              <span className={`h-2 w-2 rounded-full ${systemHealth?.status === 'online' ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
              <span className="text-slate-400">AI Model:</span>
              <span className="font-mono text-slate-200">
                {systemHealth?.model_ready ? 'ViT-Base (Active)' : 'Connecting...'}
              </span>
            </div>

            <div className="flex items-center space-x-1.5 text-slate-400 bg-slate-950/70 border border-slate-800 px-2.5 py-1.5 rounded-full">
              <Database className="h-3.5 w-3.5 text-cyan-400" />
              <span>SQLite</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
