"""
MesoNet Deepfake Detection Architecture (Meso-4)
Reference: "MesoNet: a Compact Facial Video Forgery Detection Network" (Afchar et al., IEEE WIFS)
Specialized for detecting mesoscopic generative artifacts in facial images.
"""

import os
import torch
import torch.nn as nn
import torch.nn.functional as F

class Meso4(nn.Module):
    def __init__(self, num_classes=2):
        super(Meso4, self).__init__()
        self.num_classes = num_classes

        # Block 1
        self.conv1 = nn.Conv2d(3, 8, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(8)
        self.relu1 = nn.ReLU(inplace=True)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)

        # Block 2
        self.conv2 = nn.Conv2d(8, 8, kernel_size=5, padding=2, bias=False)
        self.bn2 = nn.BatchNorm2d(8)
        self.relu2 = nn.ReLU(inplace=True)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)

        # Block 3
        self.conv3 = nn.Conv2d(8, 16, kernel_size=5, padding=2, bias=False)
        self.bn3 = nn.BatchNorm2d(16)
        self.relu3 = nn.ReLU(inplace=True)
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)

        # Block 4 (Target Layer for Grad-CAM)
        self.conv4 = nn.Conv2d(16, 16, kernel_size=5, padding=2, bias=False)
        self.bn4 = nn.BatchNorm2d(16)
        self.relu4 = nn.ReLU(inplace=True)
        self.pool4 = nn.MaxPool2d(kernel_size=4, stride=4)

        # Fully Connected Layers (Assumes input 256x256 -> 8x8 spatial output)
        self.dropout1 = nn.Dropout(0.5)
        self.fc1 = nn.Linear(16 * 8 * 8, 16)
        self.leaky_relu = nn.LeakyReLU(0.1)
        self.dropout2 = nn.Dropout(0.5)
        self.fc2 = nn.Linear(16, num_classes)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        # Forward through convolutional blocks
        x = self.pool1(self.relu1(self.bn1(self.conv1(x))))
        x = self.pool2(self.relu2(self.bn2(self.conv2(x))))
        x = self.pool3(self.relu3(self.bn3(self.conv3(x))))
        x = self.pool4(self.relu4(self.bn4(self.conv4(x))))

        # Flatten
        x = x.view(x.size(0), -1)

        # Classifier
        x = self.dropout1(x)
        x = self.leaky_relu(self.fc1(x))
        x = self.dropout2(x)
        x = self.fc2(x)
        return x

    def predict_probability(self, tensor_input):
        """
        Computes softmax probability for binary classification [P(Real), P(Fake)]
        """
        self.eval()
        with torch.no_grad():
            logits = self.forward(tensor_input)
            probs = F.softmax(logits, dim=1)
            fake_prob = float(probs[0, 1].item())
            real_prob = float(probs[0, 0].item())
            return {'real_prob': real_prob, 'fake_prob': fake_prob}
