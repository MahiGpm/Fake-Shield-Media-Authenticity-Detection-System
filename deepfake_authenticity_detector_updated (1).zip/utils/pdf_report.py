"""
Automated Forensic PDF Audit Report Generator
Creates academic and legal digital evidence certificates with cryptographic checksums and visual evidence.
"""

import os
import io
import datetime
import numpy as np
from PIL import Image

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, KeepTogether, HRFlowable
)

def generate_forensic_pdf(report_data, output_path):
    """
    Generates a professional forensic verification report in PDF format.
    Args:
        report_data: dict containing:
            'filename': str
            'timestamp': str
            'md5': str
            'sha256': str
            'authenticity_pct': float
            'overall_fake_prob': float
            'verdict': str
            'risk_level': str
            'modalities': dict
            'findings': list of str
            'face_rgb_np': np.ndarray (optional)
            'gradcam_rgb_np': np.ndarray (optional)
            'ela_rgb_np': np.ndarray (optional)
            'fft_rgb_np': np.ndarray (optional)
        output_path: str or Path
    """
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    story = []
    styles = getSampleStyleSheet()

    # Custom styling
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        textColor=colors.HexColor('#0F172A'),
        spaceAfter=4,
        alignment=1 # Center
    )
    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        textColor=colors.HexColor('#475569'),
        spaceAfter=15,
        alignment=1
    )
    section_heading = ParagraphStyle(
        'SecHead',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        textColor=colors.HexColor('#1E293B'),
        spaceBefore=12,
        spaceAfter=6
    )
    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        textColor=colors.HexColor('#334155'),
        leading=12
    )

    # Header
    story.append(Paragraph("DIGITAL MEDIA FORENSIC AUDIT CERTIFICATE", title_style))
    story.append(Paragraph("VeriFace AI | Deepfake Media Authenticity & Forensic Inspection System", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#0284C7'), spaceAfter=12))

    # Executive Verdict Banner Table
    is_fake = report_data.get('overall_fake_prob', 0) >= 0.50
    verdict_bg = colors.HexColor('#FEE2E2') if is_fake else colors.HexColor('#DCFCE7')
    verdict_text_color = colors.HexColor('#991B1B') if is_fake else colors.HexColor('#166534')

    verdict_data = [
        [
            Paragraph(f"<b>FINAL AUDIT VERDICT:</b> {report_data.get('verdict', 'UNKNOWN')}",
                      ParagraphStyle('V1', fontName='Helvetica-Bold', fontSize=14, textColor=verdict_text_color)),
            Paragraph(f"<b>AUTHENTICITY SCORE:</b> {report_data.get('authenticity_pct', 0.0)}%",
                      ParagraphStyle('V2', fontName='Helvetica-Bold', fontSize=14, textColor=verdict_text_color, alignment=2))
        ],
        [
            Paragraph(f"<b>Risk Classification:</b> {report_data.get('risk_level', 'UNKNOWN')}",
                      ParagraphStyle('V3', fontName='Helvetica', fontSize=10, textColor=verdict_text_color)),
            Paragraph(f"<b>Forensic Confidence:</b> {'High (Ensemble Consensus)' if abs(report_data.get('overall_fake_prob', 0.5) - 0.5) > 0.25 else 'Moderate'}",
                      ParagraphStyle('V4', fontName='Helvetica', fontSize=10, textColor=verdict_text_color, alignment=2))
        ]
    ]

    verdict_table = Table(verdict_data, colWidths=[270, 270])
    verdict_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), verdict_bg),
        ('BOX', (0, 0), (-1, -1), 1, verdict_text_color),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.transparent),
        ('PADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(verdict_table)
    story.append(Spacer(1, 10))

    # Section 1: Chain of Custody & Metadata
    story.append(Paragraph("1. Digital Chain of Custody & Evidence Metadata", section_heading))
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")

    meta_rows = [
        [Paragraph("<b>Target File Name:</b>", body_style), Paragraph(report_data.get('filename', 'Unknown'), body_style)],
        [Paragraph("<b>Inspection Date:</b>", body_style), Paragraph(report_data.get('timestamp', now_str), body_style)],
        [Paragraph("<b>MD5 Checksum:</b>", body_style), Paragraph(report_data.get('md5', 'N/A'), body_style)],
        [Paragraph("<b>SHA-256 Digest:</b>", body_style), Paragraph(report_data.get('sha256', 'N/A'), body_style)],
        [Paragraph("<b>Inspection Engine:</b>", body_style), Paragraph("MesoNet-4 + 2D FFT + Error Level Analysis v2.4", body_style)],
    ]
    meta_table = Table(meta_rows, colWidths=[140, 400])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F8FAFC')),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E2E8F0')),
        ('PADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 10))

    # Section 2: Multimodal Modality Scores Table
    story.append(Paragraph("2. Multimodal Forensic Modality Breakdown", section_heading))
    modalities = report_data.get('modalities', {})

    score_rows = [
        [
            Paragraph("<b>Forensic Modality</b>", body_style),
            Paragraph("<b>Target Artifact</b>", body_style),
            Paragraph("<b>Anomaly Risk (0-100%)</b>", body_style),
            Paragraph("<b>Modality Finding</b>", body_style)
        ],
        [
            Paragraph("Spatial Deep Learning (MesoNet-4)", body_style),
            Paragraph("Facial blending & mesoscopic feature anomalies", body_style),
            Paragraph(f"{int(modalities.get('spatial_dl', 0)*100)}%", body_style),
            Paragraph("FLAGGED" if modalities.get('spatial_dl', 0) > 0.5 else "NORMAL", body_style)
        ],
        [
            Paragraph("Error Level Analysis (ELA)", body_style),
            Paragraph("JPEG compression rate discontinuities", body_style),
            Paragraph(f"{int(modalities.get('compression_ela', 0)*100)}%", body_style),
            Paragraph("FLAGGED" if modalities.get('compression_ela', 0) > 0.5 else "NORMAL", body_style)
        ],
        [
            Paragraph("Frequency Spectral Forensics (2D FFT)", body_style),
            Paragraph("High-frequency GAN periodic upsampling grid", body_style),
            Paragraph(f"{int(modalities.get('frequency_fft', 0)*100)}%", body_style),
            Paragraph("FLAGGED" if modalities.get('frequency_fft', 0) > 0.5 else "NORMAL", body_style)
        ],
        [
            Paragraph("Boundary Noise Variance", body_style),
            Paragraph("Seam edge sharpness & sensor noise profile", body_style),
            Paragraph(f"{int(modalities.get('noise_boundary', 0)*100)}%", body_style),
            Paragraph("FLAGGED" if modalities.get('noise_boundary', 0) > 0.5 else "NORMAL", body_style)
        ]
    ]

    score_table = Table(score_rows, colWidths=[150, 170, 110, 110])
    score_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0F172A')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#94A3B8')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ('PADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(score_table)
    story.append(Spacer(1, 10))

    # Section 3: Visual Forensic Evidence
    story.append(Paragraph("3. Visual Evidence Exhibits (ELA & Spectral Analysis)", section_heading))

    temp_img_paths = []
    try:
        def save_temp_pil(arr, prefix):
            tmp_p = f"temp_{prefix}_{datetime.datetime.now().microsecond}.jpg"
            if isinstance(arr, np.ndarray):
                if len(arr.shape) == 2:
                    im = Image.fromarray(arr)
                elif arr.shape[2] == 3:
                    im = Image.fromarray(arr)
                else:
                    im = Image.fromarray(arr)
            elif isinstance(arr, Image.Image):
                im = arr
            else:
                return None
            im.resize((200, 200)).save(tmp_p, format='JPEG', quality=85)
            temp_img_paths.append(tmp_p)
            return tmp_p

        p1 = save_temp_pil(report_data.get('face_rgb_np'), 'orig')
        p2 = save_temp_pil(report_data.get('gradcam_rgb_np'), 'cam')
        p3 = save_temp_pil(report_data.get('ela_rgb_np'), 'ela')
        p4 = save_temp_pil(report_data.get('fft_rgb_np'), 'fft')

        if p1 and p2 and p3 and p4:
            img_table_data = [
                [RLImage(p1, width=125, height=125), RLImage(p2, width=125, height=125),
                 RLImage(p3, width=125, height=125), RLImage(p4, width=125, height=125)],
                [Paragraph("<b>Fig A:</b> Analyzed Face", body_style),
                 Paragraph("<b>Fig B:</b> Grad-CAM Attention", body_style),
                 Paragraph("<b>Fig C:</b> ELA Compression", body_style),
                 Paragraph("<b>Fig D:</b> 2D FFT Spectrum", body_style)]
            ]
            img_table = Table(img_table_data, colWidths=[135, 135, 135, 135])
            img_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('PADDING', (0, 0), (-1, -1), 4),
            ]))
            story.append(img_table)
    except Exception as e:
        story.append(Paragraph(f"<i>Visual evidence generation note: {str(e)}</i>", body_style))

    story.append(Spacer(1, 15))

    # Section 4: Forensic Findings & Examiner Sign-off
    story.append(Paragraph("4. Detailed Forensic Observations & Legal Sign-off", section_heading))
    findings = report_data.get('findings', [])
    for f in findings:
        story.append(Paragraph(f"• {f}", body_style))

    story.append(Spacer(1, 15))
    sign_rows = [
        [Paragraph("<b>Lead Digital Forensics Examiner:</b>", body_style), Paragraph("___________________________", body_style)],
        [Paragraph("<b>Automated Verification Checksum:</b>", body_style), Paragraph(f"VERIFIED-{report_data.get('md5', 'OK')[:12].upper()}", body_style)]
    ]
    sign_table = Table(sign_rows, colWidths=[200, 340])
    sign_table.setStyle(TableStyle([('PADDING', (0, 0), (-1, -1), 4)]))
    story.append(sign_table)

    # Build PDF
    doc.build(story)

    # Clean up temp images
    for p in temp_img_paths:
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass

    return output_path
