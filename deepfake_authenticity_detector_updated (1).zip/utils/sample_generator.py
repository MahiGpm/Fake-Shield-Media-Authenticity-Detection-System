"""
Benchmark Test Media Generator
Generates realistic authentic and synthetic deepfake samples and test video clips
for immediate evaluation and viva demonstrations.
"""

import os
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

def draw_photorealistic_face(seed=42):
    """Generates an authentic synthetic portrait with natural sensor noise."""
    np.random.seed(seed)
    w, h = 300, 300
    img = np.zeros((h, w, 3), dtype=np.uint8)

    # Soft studio portrait gradient background
    for y in range(h):
        val = int(70 + 35 * (y / h))
        img[y, :] = [val + 10, val, val - 10]

    # Draw head / face oval
    cv2.ellipse(img, (150, 160), (75, 105), 0, 0, 360, (190, 215, 240), -1)

    # Hair
    cv2.ellipse(img, (150, 115), (85, 60), 0, 0, 180, (30, 35, 45), -1)

    # Eyes
    cv2.circle(img, (120, 145), 14, (255, 255, 255), -1)
    cv2.circle(img, (180, 145), 14, (255, 255, 255), -1)
    cv2.circle(img, (120, 145), 7, (70, 45, 30), -1)
    cv2.circle(img, (180, 145), 7, (70, 45, 30), -1)
    cv2.circle(img, (122, 143), 2, (255, 255, 255), -1) # Specular glint
    cv2.circle(img, (182, 143), 2, (255, 255, 255), -1)

    # Eyebrows
    cv2.ellipse(img, (120, 130), (18, 5), -10, 0, 180, (40, 30, 20), 3)
    cv2.ellipse(img, (180, 130), (18, 5), 10, 0, 180, (40, 30, 20), 3)

    # Nose
    pts = np.array([[150, 150], [144, 180], [156, 180]], np.int32)
    cv2.polylines(img, [pts], False, (160, 185, 210), 2)

    # Lips
    cv2.ellipse(img, (150, 210), (28, 12), 0, 0, 360, (100, 120, 195), -1)
    cv2.line(img, (125, 210), (175, 210), (70, 80, 160), 2)

    # Apply subtle realistic optical lens blur and sensor shot noise
    img = cv2.GaussianBlur(img, (5, 5), 0.8)
    sensor_noise = np.random.normal(0, 3.5, img.shape).astype(np.int16)
    noisy_img = np.clip(img.astype(np.int16) + sensor_noise, 0, 255).astype(np.uint8)

    return noisy_img

def draw_deepfake_face(seed=99):
    """Generates a face with characteristic deepfake blending, GAN grid, and compression anomalies."""
    base = draw_photorealistic_face(seed=seed)
    h, w = base.shape[:2]

    # Artifact 1: Periodic GAN high-frequency grid noise (checkerboard artifact from upsampling)
    y_coords, x_coords = np.indices((h, w))
    gan_grid = (np.sin(x_coords * 0.9) * np.cos(y_coords * 0.9) * 14).astype(np.int16)
    
    # Face region mask
    mask = np.zeros((h, w), dtype=np.float32)
    cv2.ellipse(mask, (150, 160), (65, 90), 0, 0, 360, 1.0, -1)
    mask = cv2.GaussianBlur(mask, (21, 21), 8.0) # Unnatural soft boundary feathering

    # Artifact 2: Warping around eyes and mouth (blur + re-sharpening discontinuity)
    warped_inner = cv2.GaussianBlur(base, (9, 9), 3.0)
    
    # Blend base with warped face
    deepfake = base.copy().astype(np.float32)
    for c in range(3):
        deepfake[:, :, c] = deepfake[:, :, c] * (1.0 - mask) + (warped_inner[:, :, c] + gan_grid * 0.8) * mask

    deepfake = np.clip(deepfake, 0, 255).astype(np.uint8)

    # Artifact 3: Compression disparity (re-encode inner face to JPEG 40, background remains clean)
    face_roi = deepfake[90:240, 80:220]
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 35]
    _, enc = cv2.imencode('.jpg', face_roi, encode_param)
    dec = cv2.imdecode(enc, 1)
    deepfake[90:240, 80:220] = dec

    return deepfake

def generate_benchmark_assets(output_dir):
    """
    Generates real and fake benchmark test images and a test video.
    """
    real_dir = os.path.join(output_dir, "real")
    fake_dir = os.path.join(output_dir, "fake")
    os.makedirs(real_dir, exist_ok=True)
    os.makedirs(fake_dir, exist_ok=True)

    # 1. Authentic Samples
    real_sample_1 = draw_photorealistic_face(seed=101)
    real_sample_2 = draw_photorealistic_face(seed=202)
    cv2.imwrite(os.path.join(real_dir, "sample_real_01.jpg"), real_sample_1)
    cv2.imwrite(os.path.join(real_dir, "sample_real_02.jpg"), real_sample_2)

    # 2. Deepfake Samples
    fake_sample_1 = draw_deepfake_face(seed=303)
    fake_sample_2 = draw_deepfake_face(seed=404)
    cv2.imwrite(os.path.join(fake_dir, "sample_deepfake_01.jpg"), fake_sample_1)
    cv2.imwrite(os.path.join(fake_dir, "sample_deepfake_02.jpg"), fake_sample_2)

    # 3. Benchmark Test Video (60 frames, 25 FPS)
    video_path = os.path.join(output_dir, "test_video_benchmark.mp4")
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(video_path, fourcc, 20.0, (300, 300))

    # Frames 0-25: Authentic face
    for _ in range(25):
        out.write(real_sample_1)

    # Frames 26-45: Deepfake spliced face inserted
    for _ in range(20):
        out.write(fake_sample_1)

    # Frames 46-60: Returns to authentic face
    for _ in range(15):
        out.write(real_sample_2)

    out.release()
    print(f"[Benchmark] Generated test assets at: {output_dir}")
    return video_path
