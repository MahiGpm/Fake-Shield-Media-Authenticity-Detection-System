"""
Interactive Visualization Utilities for Streamlit Forensic Dashboard
Uses Plotly for responsive gauge charts, radar charts, and temporal video timeline graphs.
"""

import plotly.graph_objects as go
import numpy as np

def create_authenticity_gauge(authenticity_pct):
    """
    Creates a responsive semi-circular gauge displaying Authenticity Percentage (0-100%).
    """
    # Color logic
    if authenticity_pct >= 75:
        bar_color = "#00E676"  # Bright Green
    elif authenticity_pct >= 50:
        bar_color = "#E6C200"  # Yellow-Amber
    elif authenticity_pct >= 30:
        bar_color = "#FF9100"  # Orange
    else:
        bar_color = "#FF1744"  # Crimson Red

    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=authenticity_pct,
        number={'suffix': "%", 'font': {'size': 44, 'color': '#FFFFFF', 'family': 'Courier New'}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#777777", 'tickfont': {'color': '#AAAAAA'}},
            'bar': {'color': bar_color, 'thickness': 0.28},
            'bgcolor': "#1E222D",
            'borderwidth': 1,
            'bordercolor': "#333A48",
            'steps': [
                {'range': [0, 50], 'color': 'rgba(255, 23, 68, 0.22)'},
                {'range': [50, 75], 'color': 'rgba(230, 194, 0, 0.22)'},
                {'range': [75, 100], 'color': 'rgba(0, 230, 118, 0.22)'}
            ],
            'threshold': {
                'line': {'color': "#FFFFFF", 'width': 3},
                'thickness': 0.75,
                'value': authenticity_pct
            }
        }
    ))

    fig.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=260,
        margin=dict(l=25, r=25, t=30, b=10)
    )
    return fig

def create_radar_chart(modalities):
    """
    Creates a radar chart displaying multimodal forensic anomaly scores.
    Args:
        modalities: dict with keys 'spatial_dl', 'compression_ela', 'frequency_fft', 'noise_boundary'
    """
    categories = [
        'Spatial Deep Learning',
        'ELA Compression Discrepancy',
        'FFT High-Freq Anomalies',
        'Boundary Noise Inconsistency'
    ]
    values = [
        modalities.get('spatial_dl', 0.1),
        modalities.get('compression_ela', 0.1),
        modalities.get('frequency_fft', 0.1),
        modalities.get('noise_boundary', 0.1)
    ]
    # Close the radar loop
    values.append(values[0])
    categories.append(categories[0])

    fig = go.Figure()

    fig.add_trace(go.Scatterpolar(
        r=values,
        theta=categories,
        fill='toself',
        fillcolor='rgba(255, 51, 102, 0.35)',
        line=dict(color='#FF3366', width=2),
        name='Anomaly Score'
    ))

    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1.0],
                tickvals=[0.2, 0.4, 0.6, 0.8, 1.0],
                gridcolor='#2C3242',
                tickfont=dict(color='#8892B0')
            ),
            angularaxis=dict(
                gridcolor='#2C3242',
                tickfont=dict(color='#CCD6F6', size=11)
            ),
            bgcolor='rgba(15, 23, 42, 0.7)'
        ),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        height=320,
        margin=dict(l=40, r=40, t=30, b=30),
        showlegend=False
    )
    return fig

def create_video_timeline_chart(frame_scores):
    """
    Plots the fake probability over time for a video file.
    Args:
        frame_scores: list of dict [{'time_sec': float, 'frame_idx': int, 'fake_prob': float}]
    """
    times = [f['time_sec'] for f in frame_scores]
    probs = [f['fake_prob'] for f in frame_scores]

    fig = go.Figure()

    # Threshold horizontal reference line (50%)
    fig.add_hline(
        y=0.50,
        line_dash="dash",
        line_color="#FF3366",
        annotation_text="Deepfake Threshold (50%)",
        annotation_position="top left",
        annotation_font_color="#FF3366"
    )

    # Risk line trace
    fig.add_trace(go.Scatter(
        x=times,
        y=probs,
        mode='lines+markers',
        line=dict(color='#00D2FF', width=2.5),
        marker=dict(size=5, color=['#FF1744' if p >= 0.5 else '#00E676' for p in probs]),
        fill='tozeroy',
        fillcolor='rgba(0, 210, 255, 0.08)',
        name='Manipulation Probability',
        hovertemplate='Time: %{x:.2f}s<br>Fake Risk: %{y:.1%}<extra></extra>'
    ))

    fig.update_layout(
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(15, 23, 42, 0.6)',
        xaxis=dict(
            title="Video Timestamp (seconds)",
            gridcolor='#2C3242',
            tickfont=dict(color='#CCD6F6'),
            titlefont=dict(color='#8892B0')
        ),
        yaxis=dict(
            title="Manipulation Risk (0-1.0)",
            range=[0, 1.05],
            gridcolor='#2C3242',
            tickfont=dict(color='#CCD6F6'),
            titlefont=dict(color='#8892B0')
        ),
        height=300,
        margin=dict(l=40, r=20, t=25, b=35),
        showlegend=False
    )
    return fig
